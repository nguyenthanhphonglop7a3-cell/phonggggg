/* Kho đề: tạo đề, làm bài, chấm điểm */
const _examQuestionsCache={};function examQuestions(e){return _examQuestionsCache[e]||(_examQuestionsCache[e]=_examQuestionsRaw(e));}
function _examQuestionsRaw(e){
  // Mỗi đề dùng một cửa sổ câu hỏi khác nhau và seed riêng để tránh 10 quiz giống nhau.
  const offset=(e*5)%hardMCQ.length;
  return Array.from({length:18},(_,i)=>hardMCQ[(offset+i)%hardMCQ.length](100+e*37+i*3));
}
const _examTFCache={};function examTF(e){return _examTFCache[e]||(_examTFCache[e]=_examTFRaw(e));}
function _examTFRaw(e){
  const out=[];
  for(let i=0;i<4;i++) out.push(tfHard[(e+i*2)%tfHard.length]);
  return out;
}
const _examShortCache={};function examShort(e){return _examShortCache[e]||(_examShortCache[e]=_examShortRaw(e));}
function _examShortRaw(e){
  const base=shortHardByChapter10[e%shortHardByChapter10.length]||shortHard;
  return Array.from({length:6},(_,i)=>base[(i+e*2)%base.length]);
}
function gradeExam(e){
  const qs=examQuestions(e),tfs=examTF(e),ss=examShort(e);
  let score=0,total=18+16+6;
  qs.forEach((q,i)=>{const x=document.querySelector(`input[name="ex${e}q${i}"]:checked`);if(x&&Number(x.value)===q.correct)score++;});
  tfs.forEach((d,i)=>d.a.forEach((x,j)=>{const r=document.querySelector(`input[name="extf${e}_${i}_${j}"]:checked`);if(r&&Number(r.value)===Number(x[1]))score++;}));
  ss.forEach((q,i)=>{const inp=document.querySelector(`#exshort_${e}_${i}`);if(!inp)return;const v=Number((inp.value||'').trim().replace(',','.'));if(Number.isFinite(v)&&Math.abs(v-q.ans)<=q.tol)score++;});
  const pct=score/total*10;
  const box=$('examResult');
  if(box){box.className='block exam-score';box.innerHTML=`<b>📊 Kết quả Quiz ${String(e+1).padStart(2,'0')}:</b> ${score}/${total} ý đúng — <b>${pct.toFixed(2)}/10</b><br><span class="muted">Điểm luyện tập quy đổi từ 18 câu trắc nghiệm + 16 mệnh đề Đúng/Sai + 6 câu trả lời ngắn. Đây là thang chấm tương tác của web, không thay thế thang điểm chính thức.</span>`;box.scrollIntoView({behavior:'smooth',block:'center'});}
}
function renderExams(){
  const url='https://www.scribd.com/document/1058580176/Thuvienhoclieu-com-Bo-10-de-Thi-Thu-TN-THPT-2026-Vat-Li';
  $('examList').innerHTML=Array.from({length:10},(_,e)=>`<div class="problem"><h3>🏆 QUIZ ${String(e+1).padStart(2,'0')} — Đề ${e+1}</h3><p>${esc(examMeta[e])}</p><p><b>Cấu trúc:</b> 18 trắc nghiệm · 4 Đúng/Sai · 6 trả lời ngắn · chấm tự động.</p><button class="btn" onclick="openExam(${e})">📝 Vào Quiz ${e+1}</button> <a class="btn" href="${url}" target="_blank" rel="noopener">🔗 Mở bộ 10 đề nguồn</a></div>`).join('');
}
function openExam(e){
  const qs=examQuestions(e),tfs=examTF(e),ss=examShort(e);
  $('examList').innerHTML=`<div class="card"><button class="btn" onclick="renderExams()">← Quay lại 10 quiz</button><h2>🏆 QUIZ ${String(e+1).padStart(2,'0')} — Đề ${e+1}</h2><p>${esc(examMeta[e])}</p><div id="examResult" class="block">Chưa nộp bài.</div><div id="examInteractive"></div></div>`;
  $('examInteractive').innerHTML=qs.map((q,i)=>`<div class="problem"><h3>Phần I — Câu ${i+1}</h3><p>${esc(q.prompt)}</p>${q.opts.map((o,j)=>`<label class="option"><input type="radio" name="ex${e}q${i}" value="${j}"> <b>${String.fromCharCode(65+j)}.</b> ${esc(o)}</label>`).join('')}<button class="btn" onclick="this.nextElementSibling.classList.toggle('show')">🧩 Giải</button><div class="solve"><b>Đáp án:</b> ${String.fromCharCode(65+q.correct)}<br>${esc(q.exp)}</div></div>`).join('')+
  `<h2>Phần II — Đúng/Sai</h2>`+tfs.map((d,i)=>`<div class="problem"><h3>Câu ${i+1}: ${esc(d.title)}</h3><p>${esc(d.context)}</p>${d.a.map((x,j)=>`<div class="block"><b>${String.fromCharCode(97+j)})</b> ${esc(x[0])}<br><label><input type="radio" name="extf${e}_${i}_${j}" value="1"> Đúng</label> <label><input type="radio" name="extf${e}_${i}_${j}" value="0"> Sai</label></div>`).join('')}<button class="btn" onclick="this.nextElementSibling.classList.toggle('show')">🧩 Giải</button><div class="solve">${d.a.map((x,j)=>`<b>${String.fromCharCode(97+j)}) ${x[1]?'Đúng':'Sai'}</b> — ${esc(x[2]||'')}<br>`).join('')}</div></div>`).join('')+
  `<h2>Phần III — Trả lời ngắn</h2>`+ss.map((q,i)=>`<div class="problem"><h3>Câu ${i+1}</h3><p>${esc(q.p)}</p><input id="exshort_${e}_${i}" type="text" placeholder="Nhập đáp án số"><button class="btn" onclick="this.nextElementSibling.classList.toggle('show')">🧩 Giải</button><div class="solve">${esc(q.a)}</div></div>`).join('')+
  `<div class="block" style="position:sticky;bottom:10px"><button class="btn" onclick="gradeExam(${e})">📊 Nộp bài & chấm điểm Quiz ${e+1}</button></div>`;
}
