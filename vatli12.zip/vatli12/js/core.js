/* Hàm chung: $, esc, state, nút chọn chương, trang chủ, lý thuyết, công thức, xáo trộn câu hỏi */
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const state={chapter:1,lesson:0};

function chapterButtons(id, render){
  $(id).innerHTML=CHAPTERS.map(c=>`<button class="${c.id===state.chapter?'on':''}" data-c="${c.id}">${c.icon} Chương ${c.id}</button>`).join('');
  $(id).querySelectorAll('button').forEach(b=>b.onclick=()=>{state.chapter=+b.dataset.c;state.lesson=0;playSound('tab');render();});
}
function lessonButtons(){
  const c=CHAPTERS.find(x=>x.id===state.chapter);
  const h=c.lessons.map((l,i)=>`<button class="${i===state.lesson?'on':''}" data-i="${i}">${i+1}. ${esc(l)}</button>`).join('');
  $('theoryLessons').innerHTML=h;$('formulaLessons').innerHTML=h;
  $('theoryLessons').querySelectorAll('button').forEach(b=>b.onclick=()=>{state.lesson=+b.dataset.i;playSound('tab');renderTheory();});
  $('formulaLessons').querySelectorAll('button').forEach(b=>b.onclick=()=>{state.lesson=+b.dataset.i;playSound('tab');renderFormula();});
}
function renderTheory(){
  chapterButtons('theoryChapters',renderTheory);lessonButtons();
  const c=CHAPTERS.find(x=>x.id===state.chapter),l=c.lessons[state.lesson],d=THEORY[`${c.id}|${l}`]||{},f=d.formulas||[];
  $('theoryContent').innerHTML=`<div class="card"><div class="section-title"><div><h2>${c.icon} ${esc(l)}</h2><span class="muted">Chương ${c.id} · Bài ${state.lesson+1}/${c.lessons.length}</span></div><span class="hero-badge" style="color:var(--primary);background:var(--soft);border-color:var(--line)">📖 HỌC KĨ</span></div>
  <div class="step"><b>1. Bản chất & khái niệm</b><br>${esc(d.concept||'')}</div>
  <div class="step"><b>2. Công thức trọng tâm</b><ul>${f.map(x=>`<li><code>${esc(x)}</code></li>`).join('')}</ul></div>
  <div class="step"><b>3. Điều kiện áp dụng</b><br>${esc(d.conditions||'')}</div>
  <div class="step"><b>4. Cách nhận dạng trong đề</b><br>${esc(d.exam||'')}</div>
  <div class="step"><b>5. ⚠️ Bẫy thường gặp</b><br>${esc(d.traps||'')}</div>
  <div class="step"><b>6. 💡 Ví dụ minh họa</b><br>${esc(d.example||'')}</div>
  <div class="block"><b>🎯 Checklist trước khi làm bài</b><ol><li>Đổi đơn vị về hệ SI nếu cần.</li><li>Xác định quá trình và điều kiện áp dụng.</li><li>Viết công thức gốc trước khi biến đổi.</li><li>Thay số sau khi kiểm tra đại lượng và đơn vị.</li><li>Đối chiếu dấu, độ lớn và ý nghĩa vật lí của kết quả.</li></ol></div></div>`;
}
function renderFormula(){
  chapterButtons('formulaChapters',renderFormula);lessonButtons();
  const c=CHAPTERS.find(x=>x.id===state.chapter),l=c.lessons[state.lesson],d=THEORY[`${c.id}|${l}`]||{};
  $('formulaContent').innerHTML=(d.formulas||[]).map((x,i)=>`<div class="block"><h3>${i+1}. ${esc(x)}</h3><p><b>Điều kiện:</b> ${esc(d.conditions||'')}</p><p><b>Bẫy:</b> ${esc(d.traps||'')}</p></div>`).join('');
}
function showPage(id){
  const old=document.querySelector('.page.on');
  if(old)old.classList.remove('on');
  $(id).classList.add('on');
  document.querySelectorAll('[data-page]').forEach(b=>b.classList.toggle('on',b.dataset.page===id));
  playSound('tab');
  if(id==='theory')renderTheory();else if(id==='formula')renderFormula();else if(id==='quiz')renderQuiz();else if(id==='tf')renderTF();else if(id==='short')renderShort();else if(id==='essay')renderEssay();else if(id==='exams')renderExams();
  window.scrollTo({top:0,behavior:'smooth'});
}
document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>showPage(b.dataset.page));
function renderHome(){$('homeChapters').innerHTML=CHAPTERS.map(c=>`<div class="chapter" onclick="state.chapter=${c.id};showPage('theory')"><div style="font-size:28px">${c.icon}</div><h3>Chương ${c.id} — ${esc(c.name)}</h3><p class="muted">${c.lessons.length} bài học</p></div>`).join('');}

function shuffleQ(q){
  const a=q.opts.map((x,i)=>({x,i}));
  for(let i=a.length-1;i>0;i--){const j=(q.seed+i*7)%(i+1);[a[i],a[j]]=[a[j],a[i]];}
  q.opts=a.map(x=>x.x);q.correct=a.findIndex(x=>x.i===q.correct);return q;
}
function Q(title,prompt,opts,correct,exp){
  return shuffleQ({title,prompt,opts:[...opts],correct,exp,seed:Math.floor(Math.random()*100000)});
}
