/* Trắc nghiệm theo chương: bộ sinh câu hỏi, số liệu đổi mỗi lần, đáp án tính tự động (24 câu/chương) */
const chapterHard = [];
const pick=a=>a[Math.floor(Math.random()*a.length)];
const F=(x,d=2)=>Number(x).toFixed(d).replace('.',',');
function mkQ(title,prompt,correct,wrongs,exp){
  const all=[correct,...wrongs];if(new Set(all).size<4)return null;
  const idx=[0,1,2,3];for(let i=3;i>0;i--){const j=Math.floor(Math.random()*(i+1));[idx[i],idx[j]]=[idx[j],idx[i]];}
  return {title,prompt,opts:idx.map(i=>all[i]),correct:idx.indexOf(0),exp};
}
function gen(fn,n){const out=[],seen=new Set();let g=0;while(out.length<n&&g++<300){const q=fn();if(q&&!seen.has(q.prompt)){seen.add(q.prompt);out.push(q);}}return out;}
const GEN={
1:[()=>{const m=pick([0.1,0.2,0.3]),c=pick([380,460,900]),T=pick([90,100,120]),M=pick([0.4,0.5,0.6]),C=pick([40,60,80]),t0=pick([20,25,30]);
  const Cw=M*4200+C,k=m*c,t=(k*T+Cw*t0)/(k+Cw),tw=(k*T+M*4200*t0)/(k+M*4200),sw=(Cw*T+k*t0)/(k+Cw);
  return mkQ('Nhiệt — cân bằng nhiệt có nhiệt lượng kế',`Thả vật kim loại ${F(m,1)} kg (c=${c} J/(kg·K)) ở ${T}°C vào ${F(M,1)} kg nước ở ${t0}°C trong nhiệt lượng kế có nhiệt dung ${C} J/K (c_nước=4200 J/(kg·K)). Bỏ qua mất nhiệt. Nhiệt độ cân bằng xấp xỉ`,F(t,1)+'°C',[F(tw,1)+'°C',F((T+t0)/2,1)+'°C',F(sw,1)+'°C'],`mc(T−t)=(M·4200+C)(t−t0) ⇒ t=(mcT+(M·4200+C)t0)/(mc+M·4200+C)≈${F(t,1)}°C. Bẫy: quên nhiệt dung bình (${F(tw,1)}°C) hoặc lấy trung bình cộng.`);},
 ()=>{const m=pick([0.1,0.2,0.25,0.3]),t0=pick([10,15,20,25]),P=pick([100,150,200,250]);
  const t=(m*2100*t0+m*334000)/P;
  return mkQ('Nhiệt — đun đá có chuyển thể',`Đun ${F(m,2)} kg đá ở −${t0}°C bằng bếp có công suất nhiệt hữu ích ${P} W (c_đá=2100 J/(kg·K), λ=3,34×10^5 J/kg). Thời gian để đá vừa tan hết (0°C) xấp xỉ`,F(t,0)+' s',[F(m*334000/P,0)+' s',F((m*4200*t0+m*334000)/P,0)+' s',F(m*2100*t0/P,0)+' s'],`Q=mc_đá·t0+mλ=${F(m*2100*t0+m*334000,0)} J ⇒ t=Q/P≈${F(t,0)} s. Bẫy: bỏ giai đoạn đá nóng lên, hoặc dùng nhầm c nước.`);}],
2:[()=>{const p1=pick([1,2,3]),V1=pick([2,4,6]),V2=pick([3,5,8]),t1=pick([27,47,57]),t2=pick([127,177,227]);
  const p2=p1*V1*(t2+273)/((t1+273)*V2);
  return mkQ('Khí lí tưởng — phương trình trạng thái',`Khí lí tưởng ở trạng thái 1: p=${p1}×10^5 Pa, V=${V1} L, t=${t1}°C. Chuyển sang trạng thái 2 có V=${V2} L, t=${t2}°C. Áp suất ở trạng thái 2 xấp xỉ`,F(p2,2)+'×10^5 Pa',[F(p1*V1*t2/(t1*V2),2)+'×10^5 Pa',F(p1*V2*(t2+273)/((t1+273)*V1),2)+'×10^5 Pa',F(p1*(t2+273)/(t1+273),2)+'×10^5 Pa'],`p1V1/T1=p2V2/T2 với T=t+273 ⇒ p2≈${F(p2,2)}×10^5 Pa. Bẫy: dùng °C, đảo V, hoặc bỏ qua sự đổi thể tích.`);},
 ()=>{const p=pick([1,2,3]),V=pick([2,4,5,10]),t=pick([27,47,127]);
  const n=p*1e5*V*1e-3/(8.31*(t+273));
  return mkQ('Khí lí tưởng — tính số mol',`Bình dung tích ${V} L chứa khí lí tưởng ở ${p}×10^5 Pa, ${t}°C (R=8,31 J/(mol·K)). Số mol khí xấp xỉ`,F(n,3)+' mol',[F(n*1000,3)+' mol',F(p*1e5*V*1e-3/(8.31*t),3)+' mol',F(p*1e5*V*1e-3/(8.31*273),3)+' mol'],`n=pV/(RT) với V=${V}×10^-3 m³, T=${t+273} K ⇒ n≈${F(n,3)} mol. Bẫy: quên đổi L→m³ (×1000) hoặc dùng °C thay K.`);}],
3:[()=>{const U=pick([500,1000,2000,3000,4000]),B=pick([0.1,0.2,0.25,0.5]);
  const r=Math.sqrt(2*1.67e-27*U/1.6e-19)/B*100;
  return mkQ('Từ trường — proton được tăng tốc rồi vào từ trường',`Proton (m=1,67×10^-27 kg; e=1,6×10^-19 C) tăng tốc từ nghỉ qua hiệu điện thế ${U} V rồi bay vuông góc vào từ trường đều B=${F(B,2)} T. Bán kính quỹ đạo xấp xỉ`,F(r,2)+' cm',[F(r/Math.SQRT2,2)+' cm',F(2*r,2)+' cm',F(r/2,2)+' cm'],`½mv²=eU ⇒ v=√(2eU/m); r=mv/(eB)=√(2mU/e)/B≈${F(r,2)} cm. Bẫy: quên hệ số 2 trong động năng, hoặc cho r tỉ lệ U thay vì √U.`);},
 ()=>{const B=pick([0.2,0.4,0.5]),I=pick([2,3,4,6]),l=pick([20,30,40,50]),a=pick([30,60]);
  const s=Math.sin(a*Math.PI/180),c=Math.cos(a*Math.PI/180),F0=B*I*l/100*s;
  return mkQ('Từ trường — lực từ lên dây dẫn',`Đoạn dây dài ${l} cm có dòng I=${I} A đặt trong từ trường đều B=${F(B,1)} T, dây hợp với đường sức từ góc ${a}°. Độ lớn lực từ là`,F(F0,3)+' N',[F(B*I*l/100,3)+' N',F(B*I*l/100*c,3)+' N',F(F0*100,1)+' N'],`F=BIl·sinα=${F(B,1)}·${I}·${F(l/100,2)}·sin${a}°≈${F(F0,3)} N. Bẫy: dùng cos thay sin, bỏ sin, hoặc quên đổi cm→m.`);}],
4:[()=>{const R=pick([30,40,50,60]),ZL=pick([60,80,100,120]),ZC=pick([20,40,50,140]),U=pick([100,120,200]);
  if(ZL===ZC)return null;const P=U*U*R/(R*R+(ZL-ZC)**2),Z=Math.hypot(R,ZL-ZC);
  return mkQ('Xoay chiều — công suất mạch RLC',`Mạch RLC nối tiếp: R=${R} Ω, Z_L=${ZL} Ω, Z_C=${ZC} Ω, điện áp hiệu dụng hai đầu mạch ${U} V. Công suất tiêu thụ của mạch xấp xỉ`,F(P,1)+' W',[F(U*U/R,1)+' W',F(U*U*R/(R*R+(ZL+ZC)**2),1)+' W',F(U*U/Z,1)+' W'],`Z=√(R²+(Z_L−Z_C)²)=${F(Z,1)} Ω; I=U/Z; P=I²R=U²R/Z²≈${F(P,1)} W. Bẫy: coi P=U²/R (cộng hưởng), cộng Z_L+Z_C, hoặc dùng UI không nhân cosφ.`);},
 ()=>{const L=pick([20,50,100]),C=pick([2,5,10,20,50]);
  const f=1/(2*Math.PI*Math.sqrt(L*1e-3*C*1e-6));
  return mkQ('Xoay chiều — tần số cộng hưởng',`Mạch RLC nối tiếp có L=${L} mH, C=${C} μF. Tần số dòng điện để xảy ra cộng hưởng xấp xỉ`,F(f,0)+' Hz',[F(f*2*Math.PI,0)+' Hz',F(f/(2*Math.PI),0)+' Hz',F(f*2,0)+' Hz'],`f0=1/(2π√(LC))≈${F(f,0)} Hz. Bẫy: nhầm tần số góc ω=1/√(LC) với f.`);}],
5:[()=>{const N=pick([50,100,200]),S=pick([20,50,100]),B1=pick([0.1,0.2]),B2=pick([0.5,0.7,0.9]),dt=pick([0.1,0.2,0.5]);
  const e=N*S*1e-4*(B2-B1)/dt;
  return mkQ('Cảm ứng điện từ — suất điện động cảm ứng',`Cuộn dây ${N} vòng, diện tích mỗi vòng ${S} cm², đặt vuông góc với B. B tăng đều từ ${F(B1,1)} T đến ${F(B2,1)} T trong ${F(dt,1)} s. Độ lớn suất điện động cảm ứng là`,F(e,2)+' V',[F(e/N,3)+' V',F(e*1e4,0)+' V',F(N*S*1e-4*B2/dt,2)+' V'],`|e|=N·S·ΔB/Δt=${N}·${S}×10^-4·${F(B2-B1,1)}/${F(dt,1)}≈${F(e,2)} V. Bẫy: quên N, quên đổi cm²→m², hoặc dùng B cuối thay ΔB.`);},
 ()=>{const B=pick([0.2,0.4,0.5]),l=pick([0.2,0.5]),v=pick([2,5,10]),R=pick([0.5,2,4]);
  const e=B*l*v,P=e*e/R;
  return mkQ('Cảm ứng điện từ — thanh trượt',`Thanh dẫn dài ${F(l,1)} m trượt đều với v=${v} m/s trên ray trong từ trường đều B=${F(B,1)} T (vuông góc), điện trở toàn mạch ${F(R,1)} Ω. Công suất cơ cần để duy trì chuyển động đều là`,F(P,3)+' W',[F(e,3)+' W',F(e*e*R,3)+' W',F(e/R,3)+' W'],`e=Blv=${F(e,2)} V; P=Fv=e²/R≈${F(P,3)} W. Bẫy: nhầm P với e, e·R hoặc cường độ I=e/R.`);}],
6:[()=>{const t=pick([20,30,40,50,60,70,80,90,100,120,150,200]);const d=3e8*t*1e-6/2/1000;
  return mkQ('Sóng điện từ — radar',`Radar phát xung điện từ, sóng phản xạ từ mục tiêu thu lại sau ${t} μs (c=3×10^8 m/s). Khoảng cách đến mục tiêu là`,F(d,1)+' km',[F(2*d,1)+' km',F(d/2,2)+' km',F(d*10,1)+' km'],`Sóng đi và về nên d=ct/2=3×10^8·${t}×10^-6/2=${F(d*1000,0)} m=${F(d,1)} km. Bẫy: quên chia 2 hoặc sai đơn vị μs.`);},
 ()=>{const f=pick([10,12,15,20,24,25,30,40,50,60,75,80,100,120,150]);const l=300/f;
  return mkQ('Sóng điện từ — bước sóng',`Sóng vô tuyến tần số ${f} MHz truyền trong chân không (c=3×10^8 m/s). Bước sóng là`,F(l,2)+' m',[F(150/f,2)+' m',F(600/f,2)+' m',F(30/f,2)+' m'],`λ=c/f=3×10^8/(${f}×10^6)=${F(l,2)} m. Bẫy: sai bậc độ lớn khi đổi MHz hoặc nhân/chia 2.`);}],
7:[()=>{const a=pick([1.5,2.5,3.5,4.5]),T=pick([6,8,10,12,14,16]);const r=100*Math.pow(2,-a);
  return mkQ('Hạt nhân — định luật phóng xạ',`Chất phóng xạ có chu kì bán rã ${T} ngày. Sau ${F(a*T,0)} ngày, phần trăm số hạt nhân còn lại chưa phân rã xấp xỉ`,F(r,2)+'%',[F(100-r,2)+'%',F(100/(2*a),2)+'%',F(100*Math.pow(2,-(a-1)),2)+'%'],`t/T=${a} ⇒ N/N0=2^(−${a})≈${F(r/100,4)} ⇒ ${F(r,2)}%. Bẫy: lấy phần đã phân rã (${F(100-r,2)}%) hoặc cộng/trừ chu kì sai.`);},
 ()=>{const L=[['He-4',2,4,4.0015],['Be-9',4,9,9.0100],['Li-7',3,7,7.0144],['C-12',6,12,11.9967],['N-14',7,14,13.9992],['O-16',8,16,15.9905],['Ne-20',10,20,19.9924]];const [nm,Z,A,m]=pick(L);const per=Math.random()<.5;
  const dm=Z*1.0073+(A-Z)*1.0087-m,W=dm*931.5;const k=per?A:1,u=per?' MeV/nucleon':' MeV';
  return mkQ('Hạt nhân — năng lượng liên kết',`Hạt nhân ${nm} (Z=${Z}) có khối lượng ${F(m,4)} u. Cho m_p=1,0073 u; m_n=1,0087 u; 1 u=931,5 MeV/c². ${per?'Năng lượng liên kết riêng':'Năng lượng liên kết'} của hạt nhân xấp xỉ`,F(W/k,1)+u,[F((A*1.0073-m)*931.5/k,1)+u,F((A*1.0087-m)*931.5/k,1)+u,F(per?W:W/A,1)+(per?' MeV':' MeV/nucleon')],`Δm=Z·m_p+(A−Z)·m_n−m=${F(dm,4)} u ⇒ W=Δm·931,5≈${F(W,1)} MeV. Bẫy: coi mọi nucleon là proton (hoặc nơtron), hoặc lấy năng lượng liên kết riêng (${F(W/A,1)} MeV/nucleon).`);}],
8:[()=>{const lam=pick([250,300,350,400]),A=pick([1.9,2.3,2.5,3.0]);const e=1240/lam,W=e-A;
  return mkQ('Quang điện — động năng cực đại',`Kim loại có công thoát ${F(A,1)} eV được chiếu bức xạ bước sóng ${lam} nm (hc=1240 eV·nm). Động năng ban đầu cực đại của quang electron là`,F(W,2)+' eV',[F(e,2)+' eV',F(e+A,2)+' eV',F(A,2)+' eV'],`ε=1240/${lam}=${F(e,2)} eV; W_đmax=ε−A=${F(W,2)} eV. Bẫy: lấy năng lượng photon (${F(e,2)} eV), cộng A, hoặc nhầm với công thoát.`);},
 ()=>{const P=pick([1,2,3,5]),lam=pick([450,500,600,650]);const eJ=1240/lam*1.6e-19,N=P*1e-3/eJ/1e15;
  return mkQ('Lượng tử ánh sáng — số photon',`Nguồn sáng công suất ${P} mW phát ánh sáng đơn sắc bước sóng ${lam} nm (hc=1240 eV·nm; 1 eV=1,6×10^-19 J). Số photon phát ra mỗi giây xấp xỉ`,F(N,2)+'×10^15',[F(N*10,2)+'×10^15',F(N/10,2)+'×10^15',F(N*1.6,2)+'×10^15'],`ε=1240/${lam}=${F(1240/lam,2)} eV=${F(eJ*1e19,2)}×10^-19 J; N=P/ε≈${F(N,2)}×10^15 photon/s. Bẫy: quên đổi mW→W hoặc eV→J.`);}],
9:[()=>{const pr=pick([[3,2],[4,2],[4,3],[5,2],[5,3],[5,4],[6,2],[6,3],[6,4],[3,1],[4,1],[5,1],[6,1]]);const [n,m]=pr;
  const lam=1240/(13.6*(1/(m*m)-1/(n*n)));
  return mkQ('Nguyên tử hiđrô — bước sóng vạch phổ',`Electron trong nguyên tử hiđrô chuyển từ mức n=${n} về mức n=${m} (E_n=−13,6/n² eV; hc=1240 eV·nm). Bước sóng photon phát ra xấp xỉ`,F(lam,1)+' nm',[F(1240/(13.6*(1/m-1/n)),1)+' nm',F(1240/(13.6*(1/(m*m)+1/(n*n))),1)+' nm',F(2*lam,1)+' nm'],`ΔE=13,6(1/${m}²−1/${n}²)=${F(13.6*(1/(m*m)-1/(n*n)),3)} eV ⇒ λ=hc/ΔE≈${F(lam,1)} nm. Bẫy: quên bình phương n, hoặc cộng thay vì trừ.`);},
 ()=>{const U=pick([10,12,15,20,25,30,40,45,50,60,70,80]);const l=1.24/U;
  return mkQ('Nguyên tử hiện đại — tia X',`Ống tia X hoạt động ở hiệu điện thế ${U} kV (hc=1240 eV·nm). Bỏ qua động năng ban đầu của electron, bước sóng ngắn nhất của tia X là`,F(l,4)+' nm',[F(l*10,4)+' nm',F(l/10,4)+' nm',F(l*1000,2)+' nm'],`eU=hc/λ_min ⇒ λ_min=1240/${U*1000}≈${F(l,4)} nm. Bẫy: sai bậc độ lớn khi đổi kV→V.`);}]
};
chapterHard.length=0;
for(let c=1;c<=9;c++){
  const set=GEN[c].flatMap(f=>gen(f,12));
  for(let i=set.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[set[i],set[j]]=[set[j],set[i]];}
  chapterHard.push(set);
}
