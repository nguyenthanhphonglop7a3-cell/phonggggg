/* Âm thanh, giao diện sáng/tối, khởi tạo trang */
let soundEnabled=true; let audioCtx=null;
function playSound(type='click'){
  if(!soundEnabled)return;
  try{
    audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();
    if(audioCtx.state==='suspended')audioCtx.resume();
    const o=audioCtx.createOscillator(),g=audioCtx.createGain();
    const now=audioCtx.currentTime;
    const map={click:[520,.045,.035],tab:[680,.065,.028],ok:[880,.13,.045],bad:[220,.12,.035],done:[740,.18,.05]};
    const [freq,dur,vol]=map[type]||map.click;
    o.type='sine';o.frequency.setValueAtTime(freq,now);o.frequency.exponentialRampToValueAtTime(freq*1.18,now+dur);
    g.gain.setValueAtTime(.0001,now);g.gain.exponentialRampToValueAtTime(vol,now+.008);g.gain.exponentialRampToValueAtTime(.0001,now+dur);
    o.connect(g);g.connect(audioCtx.destination);o.start(now);o.stop(now+dur+.02);
  }catch(e){}
}
function toggleSound(){soundEnabled=!soundEnabled;const b=$('soundToggle');if(b){b.textContent=soundEnabled?'🔊':'🔇';b.title=soundEnabled?'Tắt âm thanh':'Bật âm thanh';b.setAttribute('aria-pressed',String(soundEnabled));}try{localStorage.setItem('vl12-sound',soundEnabled?'on':'off')}catch(e){} if(soundEnabled)playSound('ok');}
function applyTheme(mode){
  mode=mode==='dark'?'dark':'light';
  document.documentElement.dataset.theme=mode;
  document.documentElement.style.colorScheme=mode;
  const b=$('themeToggle');
  if(b){b.textContent=mode==='dark'?'☀️':'🌙';b.title=mode==='dark'?'Chuyển sang sáng':'Chuyển sang tối';b.setAttribute('aria-pressed',String(mode==='dark'));}
  try{localStorage.setItem('vl12-theme',mode);}catch(e){}
}
function toggleTheme(){const cur=document.documentElement.dataset.theme||'light';applyTheme(cur==='dark'?'light':'dark');playSound('click');}
(function(){
  let theme='light',snd='on';
  try{theme=localStorage.getItem('vl12-theme')||'light';snd=localStorage.getItem('vl12-sound')||'on';}catch(e){}
  soundEnabled=snd!=='off';applyTheme(theme);
  const b=$('soundToggle');if(b){b.textContent=soundEnabled?'🔊':'🔇';b.title=soundEnabled?'Tắt âm thanh':'Bật âm thanh';b.setAttribute('aria-pressed',String(soundEnabled));}
})();

renderHome();renderTheory();
