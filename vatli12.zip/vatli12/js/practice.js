/* Các tab luyện tập: Trắc nghiệm, Đúng/Sai, Trả lời ngắn, Tự luận */
function checkShort(btn, expected, tol){
  const inp=btn.previousElementSibling;
  const raw=(inp.value||'').trim().replace(',', '.');
  const val=Number(raw);
  const box=btn.nextElementSibling;
  if(!raw || !Number.isFinite(val)){box.className='solve show result-no';box.textContent='Chưa nhập số hợp lệ.';return;}
  if(Math.abs(val-expected)<=tol){box.className='solve show result-ok';box.textContent='✓ Chính xác trong sai số cho phép.';}
  else{box.className='solve show result-no';box.textContent='✗ Chưa đúng. Hãy kiểm tra lại các bước và đơn vị.';}
}


function renderQuiz(){
  chapterButtons('quizChapters',renderQuiz);
  const qs=chapterHard[state.chapter-1]||buildHardSet((state.chapter-1)*2);
  $('quizBox').innerHTML=`<div class="block"><b>🧠 Bộ trắc nghiệm nâng cao — Chương ${state.chapter}</b><br><span class="muted">${qs.length} câu · tập trung suy luận nhiều bước, đồ thị, thực nghiệm và điều kiện áp dụng.</span></div>`+
    qs.map((q,i)=>`<div class="problem"><h3>📝 Câu ${i+1}. ${esc(q.title)}</h3><p>${esc(q.prompt)}</p>${q.opts.map((o,j)=>`<label class="option"><input type="radio" name="cq_${state.chapter}_${i}" value="${j}"> <b>${String.fromCharCode(65+j)}.</b> ${esc(o)}</label>`).join('')}<button class="btn" onclick="playSound('click');this.nextElementSibling.classList.toggle('show')">🧩 Xem lời giải</button><div class="solve"><b>Đáp án: ${String.fromCharCode(65+q.correct)}</b><br>${esc(q.exp)}</div></div>`).join('')+
    `<div class="block"><button class="btn primary" onclick="gradeChapterQuiz()">📊 Chấm chương ${state.chapter}</button><span id="chapterQuizResult" class="muted" style="margin-left:10px"></span></div>`;
}
function gradeChapterQuiz(){
  const qs=chapterHard[state.chapter-1]||[];let n=0;
  qs.forEach((q,i)=>{const r=document.querySelector(`input[name="cq_${state.chapter}_${i}"]:checked`);if(r&&+r.value===q.correct)n++;});
  const box=$('chapterQuizResult');if(box){box.innerHTML=`<b> ${n}/${qs.length} câu đúng — ${(n/qs.length*10).toFixed(2)}/10</b>`;box.className=n/qs.length>=.5?'result-ok':'result-no';}
  playSound(n/qs.length>=.5?'ok':'bad');
}
function renderShort(){
  chapterButtons('shortChapters',renderShort);
  const qs=shortHardByChapter10[state.chapter-1]||[];
  $('shortBox').innerHTML=`<div class="block"><b>🔢 Trả lời ngắn nâng cao — Chương ${state.chapter}</b><br><span class="muted">${qs.length} câu · nhập đáp án số · có sai số cho phép · lời giải theo từng bước.</span></div>`+
    qs.map((q,i)=>`<div class="problem"><h3>🔢 Câu ${i+1}</h3><p>${esc(q.p)}</p><input id="short_${state.chapter}_${i}" type="text" placeholder="Nhập đáp án số"><button class="btn" onclick="checkShortById(${state.chapter},${i},this)">✓ Kiểm tra</button><button class="btn" onclick="playSound('click');this.nextElementSibling.classList.toggle('show')">🧩 Xem lời giải</button><div class="solve">${esc(q.a)}</div><div id="shortResult_${state.chapter}_${i}" class="muted"></div></div>`).join('');
}
function checkShortById(ch,i,btn){
  const q=(shortHardByChapter10[ch-1]||[])[i];if(!q)return;
  const inp=$(`short_${ch}_${i}`),box=$(`shortResult_${ch}_${i}`);const raw=(inp.value||'').trim().replace(',','.');const v=Number(raw);
  if(!raw||!Number.isFinite(v)){box.className='result-no';box.textContent='⚠️ Hãy nhập một đáp án số hợp lệ.';return;}
  const ok=Math.abs(v-q.ans)<=q.tol;box.className=ok?'result-ok':'result-no';box.textContent=ok?`✓ Chính xác. Sai số cho phép ±${q.tol}.`:`✗ Chưa đúng. Đáp án chuẩn xấp xỉ ${q.ans}. Hãy xem lại đơn vị và các bước tính.`;playSound(ok?'ok':'bad');
}
function renderEssay(){
  chapterButtons('essayChapters',renderEssay);
  const qs=essayByChapter[state.chapter-1]||[];
  const sol=essaySolutions[state.chapter-1]||[];
  $('essayBox').innerHTML=`<div class="block"><b>🧠 Tự luận tổng hợp nâng cao — Chương ${state.chapter}</b><br><span class="muted">${qs.length} bài · Mỗi lời giải có công thức gốc, đại lượng cần tìm, chuỗi tính toán và kiểm tra vật lí.</span></div>`+
    qs.map((q,i)=>`<div class="problem"><h3>✍️ Tự luận ${i+1}</h3><p>${esc(q)}</p><textarea rows="10" placeholder="Trình bày: dữ kiện → mô hình → công thức gốc → biến đổi → thay số → kiểm tra → kết luận"></textarea><br><button class="btn primary" onclick="playSound('click');this.nextElementSibling.classList.toggle('show')">🧩 Xem lời giải hướng dẫn</button><div class="solve">${esc(sol[i]||essaySolutions[8][i%6])}</div></div>`).join('');
}

function tfOf(){return tfHard.filter(d=>d.ch===state.chapter);}
function renderTF(){
  chapterButtons('tfChapters',renderTF);
  const data=tfOf();
  $('tfBox').innerHTML=`<div class="block"><b>☑️ Đúng/Sai nâng cao — Chương ${state.chapter}</b><br><span class="muted">${data.length} tình huống · mỗi tình huống 4 mệnh đề a–d · tổng ${data.length*4} ý.</span></div>`+
    data.map((d,i)=>`<div class="problem"><h3>Câu ${i+1}. ${esc(d.title)}</h3><p>${esc(d.context)}</p>${d.a.map((x,j)=>`<div class="block"><b>${String.fromCharCode(97+j)})</b> ${esc(x[0])}<div><label class="option"><input type="radio" name="tf_${state.chapter}_${i}_${j}" value="1"> Đúng</label><label class="option"><input type="radio" name="tf_${state.chapter}_${i}_${j}" value="0"> Sai</label></div></div>`).join('')}<button class="btn" onclick="playSound('click');this.nextElementSibling.classList.toggle('show')">🧩 Xem lời giải</button><div class="solve">${d.a.map((x,j)=>`<b>${String.fromCharCode(97+j)}) ${x[1]?'Đúng':'Sai'}</b> — ${esc(x[2]||'')}<br>`).join('')}</div></div>`).join('')+
    `<div class="block"><button class="btn primary" onclick="gradeTFChapter()">📊 Chấm ${data.length*4} ý</button><span id="tfChapterResult" class="muted" style="margin-left:10px"></span></div>`;
}
function gradeTFChapter(){
  const data=tfOf(),tot=data.length*4;let n=0;
  data.forEach((d,i)=>d.a.forEach((x,j)=>{const r=document.querySelector(`input[name="tf_${state.chapter}_${i}_${j}"]:checked`);if(r&&+r.value===+x[1])n++;}));
  const box=$('tfChapterResult');if(box){box.innerHTML=`<b>${n}/${tot} ý đúng — ${(n/tot*10).toFixed(2)}/10</b>`;box.className=n>=tot/2?'result-ok':'result-no';}playSound(n>=tot/2?'ok':'bad');
}
