/* Tự luận: đề theo chương (chỉ số 0 = chương 1) */
const essayByChapter = [
  [
    "Thả 50 g nước đá ở −10°C vào 300 g nước ở 40°C đựng trong nhiệt lượng kế có nhiệt dung 50 J/K. Cho c_đá=2100, c_nước=4200 J/(kg·K), λ=3,34×10^5 J/kg. Hệ cách nhiệt. Xác định nhiệt độ cuối của hệ (có kiểm tra đá có tan hết không).",
    "Ấm điện 1000 W, hiệu suất 80%, đun 1,5 kg nước từ 20°C. Sau 12 phút (kể từ lúc bật) thì tắt. Cho c=4200 J/(kg·K), L=2,26×10^6 J/kg, nước sôi ở 100°C. Tính khối lượng nước đã hóa hơi.",
    "Một dây nung làm nóng nước rồi hóa hơi một phần. Biết công suất điện, thời gian và khối lượng nước còn lại, hãy tách nhiệt lượng dùng để tăng nhiệt với nhiệt lượng hóa hơi và xác định hiệu suất.",
    "Một thí nghiệm xác định nhiệt dung riêng cho kết quả lệch so với giá trị chuẩn. Hãy phân tích các nguồn thất thoát, xây dựng biểu thức hiệu chỉnh và chỉ ra dữ kiện nào phải đo thêm để phân biệt từng nguyên nhân.",
    "Một cốc nước nguội trong phòng theo mô hình gần đúng Newton. Từ ba mốc nhiệt độ theo thời gian, hãy kiểm tra mô hình, suy ra hằng số nguội và dự đoán thời điểm nước đạt nhiệt độ yêu cầu.",
    "Một mẫu vật trải qua chuỗi nung nóng–nóng chảy–tăng nhiệt chất lỏng. Hãy dựng đầy đủ đồ thị T–Q, xác định các đoạn có độ dốc khác nhau và suy ra ít nhất hai tham số vật liệu từ dữ kiện thực nghiệm."
  ],
  [
    "Quả bóng thể tích 2,5 L chứa không khí ở 1×10^5 Pa, 300 K (coi thể tích bóng không đổi). Mỗi lần bơm đẩy vào 0,125 L không khí ở 1×10^5 Pa, 300 K; nhiệt độ coi như không đổi. Bóng chịu được áp suất tối đa 3,5×10^5 Pa. a) Bơm 40 lần thì áp suất bao nhiêu? b) Nếu bóng có thể bị nắng nóng lên 47°C thì được bơm tối đa bao nhiêu lần?",
    "2 mol khí lí tưởng đơn nguyên tử, R=8,31 J/(mol·K). A: T_A=300 K. A→B đẳng áp, V_B=2V_A; B→C đẳng tích về T_C=300 K; C→A đẳng nhiệt. Tính công, nhiệt lượng, ΔU từng quá trình và hiệu suất chu trình.",
    "Một bình khí được nạp thêm khí từ nguồn áp suất cao. Biết khối lượng khí, nhiệt độ ban đầu và sau khi nạp, hãy suy ra số mol tăng thêm và áp suất cuối; giải thích vì sao không thể dùng trực tiếp công thức đẳng nhiệt.",
    "Một quả bóng khí quyển thay đổi thể tích khi lên cao. Cho quan hệ áp suất theo độ cao và nhiệt độ theo độ cao, hãy xây dựng phương trình V(h), tìm độ cao mà thể tích đạt cực đại và kiểm tra điều kiện mô hình.",
    "Một khí thực hiện chu trình với dữ liệu p–V rời rạc. Hãy tính công bằng phương pháp diện tích hình học, suy ra nhiệt lượng thuần và xác định dấu của ΔU trên từng đoạn từ định luật I nhiệt động lực học.",
    "Một lượng khí bị nén nhanh rồi giữ nhiệt độ ổn định ở trạng thái cuối. Hãy so sánh hai quá trình nén nhanh và nén chậm, phân tích công, nhiệt lượng và nội năng; chỉ ra đại lượng nào là hàm trạng thái và đại lượng nào không."
  ],
  [
    "Dây dẫn thẳng dài 0,5 m, khối lượng 30 g, treo nằm ngang bằng hai dây nhẹ mảnh, đặt trong từ trường đều thẳng đứng B=0,2 T. Cho dòng I=2 A chạy qua dây; g=9,8 m/s². Tính góc lệch α của các dây treo so với phương thẳng đứng, tổng lực căng, và cường độ dòng để α=45°.",
    "Proton (m=1,67×10^-27 kg, e=1,6×10^-19 C) được tăng tốc từ nghỉ qua hiệu điện thế 2000 V rồi bay vuông góc vào từ trường đều B=0,1 T. Tính tốc độ, bán kính quỹ đạo, và cường độ điện trường E (vuông góc B và v) để proton đi thẳng.",
    "Một dây dẫn mang dòng điện nằm trong từ trường không đều. Biết lực tổng hợp đo được ở nhiều vị trí, hãy suy ra quy luật gần đúng của B(x) và xác định vị trí cân bằng của dây.",
    "Một khung dây có dòng điện chịu mômen trong từ trường. Từ góc quay và mômen đo được, hãy xác định tích NIS hoặc B, đồng thời phân tích sai số khi góc gần 0 hoặc 90 độ.",
    "Một electron và một proton cùng đi vào vùng B với cùng động năng. Hãy so sánh bán kính, chu kì và vận tốc của chúng; giải thích đại lượng nào phụ thuộc khối lượng và đại lượng nào không.",
    "Một thanh dẫn mang dòng điện được giữ bằng dây treo trong từ trường nghiêng. Hãy dựng sơ đồ lực, lập phương trình cân bằng theo hai phương và tìm dòng điện cực đại trước khi dây treo mất lực căng."
  ],
  [
    "Đặt u=200√2cos(100πt) V vào mạch RLC nối tiếp: R=100 Ω, L=1/π H, C=10^-4/(2π) F. a) Viết biểu thức i; b) tính công suất; c) cần thay C bằng bao nhiêu để cộng hưởng và khi đó công suất là bao nhiêu?",
    "Máy biến áp lí tưởng nhưng có hiệu suất 90% khi tải: cuộn sơ cấp 1100 vòng nối 220 V, cuộn thứ cấp 60 vòng nối tải R=3 Ω. Tính U2, I2, công suất tải và cường độ dòng sơ cấp (coi hệ số công suất bằng 1).",
    "Một tụ điện được mắc vào nguồn xoay chiều và điện áp hiệu dụng đo được có sai số hệ thống. Hãy xây dựng cách hiệu chỉnh từ ba phép đo, tính công suất và phân tích điều kiện để công suất cực đại.",
    "Một đồ thị u–t của nguồn xoay chiều cho biết biên độ và độ lệch pha. Hãy suy ra phương trình tức thời, giá trị hiệu dụng và thời điểm dòng điện đạt cực đại khi mạch có hệ số công suất đã biết.",
    "Một mạch RLC thay đổi tần số để tìm cộng hưởng. Từ hai tần số tại đó công suất bằng nhau, hãy suy ra tần số cộng hưởng và độ rộng dải thông gần đúng; giải thích vai trò của R.",
    "Một hệ truyền tải điện gồm máy biến áp, đường dây và tải. Từ công suất tải và tổn hao trên dây, hãy chọn điện áp truyền tải tối ưu và định lượng mức giảm tổn hao khi tăng điện áp lên một hệ số cho trước."
  ],
  [
    "Thanh dẫn MN dài 0,4 m trượt đều với v=5 m/s trên hai ray nằm ngang trong từ trường đều thẳng đứng B=0,5 T. Điện trở toàn mạch 0,5 Ω, bỏ qua ma sát. Tính suất điện động, cường độ dòng, lực kéo cần thiết và kiểm tra bảo toàn năng lượng.",
    "Cuộn dây có độ tự cảm L=0,2 H, dòng điện giảm đều từ 5 A về 1 A trong 0,1 s. Tính suất điện động tự cảm và độ giảm năng lượng từ trường.",
    "Một cuộn dây có N vòng quay gần nam châm, đồ thị từ thông theo thời gian được đo trực tiếp. Hãy suy ra suất điện động cực đại, dấu của suất điện động theo từng khoảng và năng lượng truyền qua tải.",
    "Một thanh dẫn chuyển động trong vùng B nhưng một phần quỹ đạo nằm ngoài vùng từ trường. Hãy phân tích từng giai đoạn có và không có dòng cảm ứng, xác định xung lực điện từ và công của lực kéo.",
    "Một máy phát điện xoay chiều có điện trở trong và tải ngoài. Từ điện áp không tải, điện áp có tải và dòng điện, hãy suy ra điện trở trong, hiệu suất và công suất cực đại có thể cung cấp.",
    "Một máy biến áp có tổn hao lõi và tổn hao đồng. Từ công suất vào, điện áp hai phía và dòng tải, hãy lập cân bằng năng lượng và tìm hiệu suất cực đại theo điều kiện tải."
  ],
  [
    "Mạch dao động LC lí tưởng có L=4 μH, C=100 pF. Tính tần số và bước sóng điện từ mạch phát ra (c=3×10^8 m/s). Muốn thu sóng 60 m cần mắc thêm tụ điện song song có điện dung bao nhiêu?",
    "Nguồn phát sóng vô tuyến đẳng hướng công suất 100 W. Tính cường độ sóng tại 10 m và 20 m, và công suất thu của anten diện tích hiệu dụng 0,5 m² đặt ở 20 m.",
    "Một anten phát công suất không đổi trong không gian tự do. Biết mật độ công suất tại hai khoảng cách, hãy kiểm tra quy luật nghịch đảo bình phương và xác định công suất thu của anten có diện tích hiệu dụng đã biết.",
    "Một tín hiệu vô tuyến phản xạ qua tầng điện ly tạo hai đường truyền. Từ độ trễ giữa hai tín hiệu, hãy suy ra chênh lệch quãng đường và phân tích điều kiện giao thoa.",
    "Một hệ định vị dùng thời gian truyền sóng từ ba trạm. Hãy lập hệ phương trình khoảng cách, xác định vị trí mục tiêu và kiểm tra nghiệm có phù hợp với miền hình học hay không.",
    "Một cảm biến đo cường độ sóng điện từ qua lớp vật liệu hấp thụ. Từ ba phép đo theo chiều dày, hãy suy ra hệ số suy giảm và dự đoán chiều dày cần thiết để giảm cường độ xuống một phần trăm."
  ],
  [
    "Mẫu Po-210 (T=138 ngày, A=210) có khối lượng ban đầu 2,0 g (N_A=6,02×10^23). Tính hoạt độ ban đầu và số hạt nhân đã phân rã sau 276 ngày.",
    "Tính năng lượng liên kết và năng lượng liên kết riêng của He-4. Cho m_p=1,0073 u, m_n=1,0087 u, m_He=4,0015 u, 1 u=931,5 MeV/c².",
    "Một hỗn hợp hai đồng vị có hai chu kỳ bán rã khác nhau. Từ đường cong hoạt độ tổng, hãy tách đóng góp của từng đồng vị và tìm thời điểm hai hoạt độ bằng nhau.",
    "Một chất phóng xạ phát alpha và beta với năng lượng khác nhau. Hãy tính năng lượng tỏa ra trong một khoảng thời gian, xét hoạt độ giảm theo thời gian và hiệu suất hấp thụ của vật liệu.",
    "Một phép đo phóng xạ có nền bức xạ không đổi. Từ số đếm trước và sau khi đặt mẫu, hãy hiệu chỉnh nền, ước lượng hoạt độ thực và phân tích ảnh hưởng của thời gian đếm đến sai số thống kê.",
    "Một mẫu cổ vật được định tuổi bằng đồng vị phóng xạ. Từ tỉ số hoạt độ hiện tại so với mẫu chuẩn và chu kỳ bán rã, hãy suy ra tuổi; sau đó đánh giá độ nhạy của kết quả khi số đo có sai số phần trăm."
  ],
  [
    "Catot tế bào quang điện có giới hạn quang điện 0,66 μm. Chiếu ánh sáng 0,33 μm công suất 3 mW, hiệu suất lượng tử 1%. Tính hiệu điện thế hãm và cường độ dòng quang điện bão hòa (hc=1240 eV·nm; e=1,6×10^-19 C).",
    "Laser He-Ne công suất 2 mW, bước sóng 632,8 nm, chùm có đường kính 2 mm. Tính năng lượng photon, số photon phát ra mỗi giây và cường độ chùm (h=6,625×10^-34 J·s).",
    "Một kim loại được chiếu bằng ba bước sóng khác nhau. Có một bước sóng không gây quang điện. Hãy xác định khoảng giá trị công thoát và dùng thêm điện thế hãm của một bước sóng để chốt giá trị.",
    "Một photon có bước sóng biến đổi sau khi tương tác với electron. Hãy lập cân bằng năng lượng, xác định độ biến thiên động năng và phân tích giới hạn khi góc tán xạ thay đổi.",
    "Một nguồn laser chiếu lên kim loại với công suất quang học biết trước. Hãy tính số photon tới mỗi giây, năng lượng mỗi photon và tốc độ electron quang điện cực đại nếu hiệu suất lượng tử được cho.",
    "Một cảm biến quang điện thay đổi cường độ chiếu nhưng giữ tần số. Từ dòng bão hòa và điện thế hãm, hãy suy ra đại lượng nào thay đổi, đại lượng nào không, và kiểm tra bằng mô hình Einstein."
  ],
  [
    "Nguyên tử hiđrô bị kích thích lên n=4. Có tối đa bao nhiêu vạch phát xạ? Tính bước sóng dài nhất và ngắn nhất (E_n=−13,6/n² eV; hc=1240 eV·nm).",
    "Ống tia X hoạt động ở U=20 kV, dòng 10 mA, coi 99% động năng chùm electron biến thành nhiệt ở anot. Tính bước sóng ngắn nhất của tia X và công suất nhiệt (hc=1240 eV·nm).",
    "Một ống tia X hoạt động ở nhiều hiệu điện thế. Từ bước sóng ngắn nhất đo được, hãy xác định điện áp gia tốc và kiểm tra sai lệch so với giá trị cài đặt.",
    "Một phổ nguyên tử có các vạch thuộc nhiều dãy. Hãy dùng một vạch đã biết để xác định các mức liên quan, sau đó dự đoán vạch có bước sóng lớn nhất trong cùng dãy.",
    "Một electron trong nguyên tử chuyển qua ba mức năng lượng liên tiếp. Hãy lập sơ đồ mức, tính năng lượng photon ở từng bước và xác định photon nào có tần số lớn nhất.",
    "Một ống tia X có dòng điện và thời gian phát tia đã biết. Hãy tính năng lượng điện cung cấp, năng lượng tối đa của một electron, bước sóng giới hạn và phân tích hiệu suất nếu năng lượng tia X đo được."
  ],
  [
    "Một chu trình nhiệt có các đoạn đẳng áp, đẳng tích và đẳng nhiệt. Hãy tính công, nhiệt lượng và ΔU từng đoạn, sau đó xác định hiệu suất chu trình từ diện tích trên đồ thị p–V.",
    "Một hệ nhiệt–khí được gia nhiệt bằng nguồn điện có hiệu suất hữu hạn. Từ công suất, thời gian và biến thiên trạng thái khí, hãy tách phần năng lượng làm tăng nội năng khỏi phần dùng thực hiện công.",
    "Một bài thực nghiệm cho đồng thời dữ liệu nhiệt độ, áp suất và thể tích ở nhiều thời điểm. Hãy kiểm tra phương trình trạng thái, phát hiện điểm dữ liệu bất thường và ước lượng trạng thái bị lỗi.",
    "Một thiết bị điện từ làm việc trong môi trường nhiệt. Hãy lập cân bằng năng lượng gồm công điện, nhiệt tỏa, công cơ và năng lượng tích trữ; xác định hiệu suất tổng từ dữ liệu đo.",
    "Một hệ có hai giai đoạn: khí thực hiện công lên piston rồi truyền năng lượng cho tải điện cảm ứng. Hãy nối các định luật cơ, nhiệt và điện từ để tìm đại lượng cuối cùng từ các dữ kiện trung gian.",
    "Một bảng dữ liệu tổng hợp gồm nhiệt học, khí lí tưởng, điện xoay chiều và hạt nhân. Hãy chọn mô hình đúng cho từng đoạn, chỉ ra dữ kiện thừa, giải theo chuỗi và kiểm tra toàn bộ kết quả bằng đơn vị cùng giới hạn vật lí."
  ]
];

/* Tự luận: lời giải tương ứng với essayByChapter */
const essaySolutions = [
  [
    "Bước 1 (kiểm tra trạng thái): Nhiệt cần để đá lên 0°C và tan hết: 0,05·2100·10 + 0,05·3,34×10^5 = 1050 + 16700 = 17750 J. Nhiệt tối đa nước và bình tỏa khi xuống 0°C: (0,3·4200+50)·40 = 52400 J > 17750 J nên đá tan hết và nhiệt độ cuối t>0. Bước 2 (cân bằng nhiệt): 17750 + 0,05·4200·t = (0,3·4200+50)(40−t) ⇒ 17750+210t = 52400−1310t ⇒ t = 34650/1520 ≈ 22,8°C. Giải thích: nếu bỏ qua bước kiểm tra mà giả sử đá không tan hết thì sẽ ra nhiệt độ 0°C là sai. Đáp số: ≈22,8°C.",
    "Điện năng hữu ích: Q=0,8·1000·720=576000 J. Nhiệt đưa nước đến sôi: 1,5·4200·80=504000 J. Phần còn lại dùng hóa hơi: 576000−504000=72000 J ⇒ m=72000/2,26×10^6≈0,0319 kg≈31,9 g. Giải thích: đoạn hóa hơi nhiệt độ giữ 100°C nên dùng Q=mL, không dùng mcΔT. Đáp số: ≈31,9 g.",
    "Điện năng cung cấp W=Pt. Nhiệt hữu ích gồm Q_1=mcΔT và Q_2=m_hL. Nếu hiệu suất η thì Q_1+Q_2=ηPt. Từ khối lượng nước còn lại suy ra m_h=m_đầu−m_còn. Sau đó giải L hoặc η theo đại lượng đề hỏi.",
    "Xác định sai số hệ thống và ngẫu nhiên. Viết phương trình đo thực nghiệm, sau đó thêm các thành phần thất thoát như Q_loss=kΔT hoặc công suất hao phí nếu đề cho mô hình. So sánh giá trị đo với chuẩn; thay đổi từng đại lượng đo trong mô hình để xem yếu tố nào gây sai lệch có hướng.",
    "Dùng mô hình Newton: dT/dt=−k(T−T_môi trường). Với dữ liệu rời rạc, tính ln[(T−T_môi trường)/(T_0−T_môi trường)] và kiểm tra quan hệ tuyến tính theo t. Hệ số góc bằng −k. Sau đó giải T(t)=T_môi trường+(T_0−T_môi trường)e^(−kt) để tìm thời điểm cần thiết.",
    "Vẽ T theo Q. Đoạn tăng nhiệt có độ dốc dT/dQ=1/(mc), đoạn chuyển thể là đoạn nằm ngang nếu áp suất phù hợp. Từ độ dốc suy ra c=1/(m·slope); từ độ dài đoạn chuyển thể suy ra λ=ΔQ/m. Nếu có đoạn hóa hơi, dùng tương tự Q=mL."
  ],
  [
    "a) Tổng thể tích khí ở 1×10^5 Pa: 2,5+40·0,125=7,5 L, nén đẳng nhiệt vào 2,5 L: p=1·7,5/2,5=3×10^5 Pa. b) Ở 47°C (320 K) áp suất không được vượt 3,5×10^5 Pa. Quy về 300 K: p ≤ 3,5×10^5·300/320 ≈ 3,28×10^5 Pa. Tổng thể tích khí ở 1×10^5 Pa: V=3,28·2,5≈8,20 L ⇒ khí bơm thêm 8,20−2,5=5,70 L ⇒ n≤5,70/0,125≈45,6. Vậy tối đa 45 lần (làm tròn xuống để an toàn). Giải thích: phải xét điều kiện xấu nhất (nhiệt độ cao nhất), không chỉ điều kiện lúc bơm.",
    "A→B: T_B=600 K; A_khí=nRΔT=2·8,31·300=4986 J; ΔU=1,5nRΔT=7479 J; Q=12465 J. B→C: A=0; ΔU=−7479 J; Q=−7479 J. C→A (nén đẳng nhiệt): ΔU=0; A=nRT·ln(V_A/V_C)=4986·ln0,5≈−3456 J; Q=−3456 J. Kiểm tra: tổng A=1530 J và tổng Q=12465−7479−3456=1530 J nên ΔU chu trình bằng 0. Hiệu suất H=A/Q_nhận=1530/12465≈12,3%. Giải thích: chỉ tính Q_nhận là phần dương (đoạn A→B).",
    "Số mol tăng thêm tính từ Δn=(p_2V/RT_2)−(p_1V/RT_1) nếu bình cứng. Không dùng công thức đẳng nhiệt khi T thay đổi. Nếu quá trình nạp có trao đổi nhiệt, phải dùng phương trình trạng thái cho trạng thái đầu/cuối và cân bằng năng lượng nếu đề yêu cầu.",
    "Viết V(h)=nRT(h)/p(h). Thay các hàm p(h), T(h) đề cho rồi tìm cực trị bằng đạo hàm hoặc so sánh. Kiểm tra miền h và điều kiện p,T dương. Nếu chỉ có dữ liệu rời rạc thì dùng bảng/đồ thị để xác định cực đại trong miền đo.",
    "Với đồ thị p−V, công bằng diện tích có dấu: giãn nở W>0, nén W<0. Dùng ΔU=nC_VΔT để suy ra Q=ΔU+W trên từng đoạn. Nếu chỉ xét toàn chu trình thì ΔU=0 nên Q_net=W_net bằng diện tích có hướng của chu trình.",
    "Quá trình nén nhanh gần đoạn nhiệt nên Q≈0 và ΔU≈−W (với W là công khí thực hiện, W<0 khi bị nén). Nén chậm có thời gian trao đổi nhiệt nên Q khác 0. Nội năng khí lí tưởng chỉ phụ thuộc T nên là hàm trạng thái; Q và W phụ thuộc đường đi."
  ],
  [
    "Lực từ nằm ngang F=BIl=0,2·2·0,5=0,2 N; trọng lực P=0,03·9,8=0,294 N. Cân bằng: tanα=F/P=0,68 ⇒ α≈34,2°. Tổng lực căng T=√(F²+P²)=√(0,04+0,0864)≈0,356 N. Để α=45° cần F=P ⇒ I=P/(Bl)=0,294/(0,2·0,5)=2,94 A. Giải thích: từ trường thẳng đứng nên lực từ nằm ngang vuông góc cả dây và B, cùng với trọng lực tạo thành tam giác lực.",
    "Định lí động năng: ½mv²=eU ⇒ v=√(2eU/m)=√(2·1,6×10^-19·2000/1,67×10^-27)≈6,19×10^5 m/s. Lực Lorentz là lực hướng tâm: r=mv/(eB)=1,67×10^-27·6,19×10^5/(1,6×10^-19·0,1)≈0,0646 m≈6,5 cm. Đi thẳng khi eE=evB ⇒ E=vB≈6,19×10^4 V/m. Giải thích: vận tốc không phụ thuộc B vì từ trường không sinh công.",
    "Với mỗi vị trí, lực từ F(x)=B(x)ILsinθ. Nếu I,L,θ cố định thì B(x)=F(x)/(ILsinθ). Dùng bảng số liệu dựng B theo x, tìm vị trí lực cân bằng bằng điều kiện tổng lực bằng 0 hoặc lực từ cân bằng lực ngoài.",
    "Mômen từ của khung: M=NISBsinθ. Từ M đo được và các đại lượng đã biết, suy ra đại lượng cần tìm. Khi θ gần 0°, sinθ nhỏ nên độ nhạy thấp; khi θ gần 90°, mômen cực đại nhưng biến thiên theo góc quanh điểm này có thể cần xét sai số đo góc.",
    "Cùng động năng K thì v=√(2K/m), nên electron có vận tốc lớn hơn proton. Bán kính r=mv/(|q|B)=√(2mK)/(|q|B), nên proton có bán kính lớn hơn. Chu kì T=2πm/(|q|B) phụ thuộc m, không phụ thuộc v trong mô hình không tương đối tính.",
    "Vẽ sơ đồ gồm mg, hai lực căng và lực từ. Chiếu theo hai phương để có hệ phương trình. Từ điều kiện dây sắp mất lực căng, đặt T=0 và giải I tới hạn. Kiểm tra chiều lực bằng quy tắc bàn tay trái và điều kiện sinθ."
  ],
  [
    "Z_L=100 Ω, Z_C=1/(ωC)=200 Ω, Z=√(100²+100²)=100√2 Ω. I=U/Z=√2 A nên I0=2 A. tanφ=(Z_L−Z_C)/R=−1 nên φ=−π/4 (u trễ pha hơn i) ⇒ i=2cos(100πt+π/4) A. b) P=I²R=2·100=200 W. c) Cộng hưởng khi Z_C=Z_L=100 Ω ⇒ C=1/(ω·100)=10^-4/π F; P_max=U²/R=200²/100=400 W. Giải thích: Z_C>Z_L nên mạch có tính dung kháng, cần giảm Z_C (tăng C) để cộng hưởng.",
    "U2=U1·N2/N1=220·60/1100=12 V. I2=U2/R=4 A. P2=U2I2=48 W. H=P2/P1=0,9 ⇒ P1=48/0,9≈53,3 W ⇒ I1=P1/U1=53,3/220≈0,242 A. Giải thích: hiệu suất 90% nghĩa là công suất sơ cấp lớn hơn công suất tải; không dùng I1/I2=N2/N1 (chỉ đúng khi H=100%).",
    "Với tụ điện, tính Z_C=1/(ωC). Nếu có sai số hệ thống ở U, trước hết hiệu chỉnh U theo hệ số hoặc độ lệch đã cho. Sau đó tính I=U/Z và P=UIcosφ. Công suất cực đại của mạch RLC nối tiếp xảy ra khi cộng hưởng Z nhỏ nhất, tức X_L=X_C.",
    "Từ đồ thị u(t)=U_0cos(ωt+φ), suy ra U=U_0/√2. Chu kì T và ω=2π/T. Nếu biết cosφ và mạch RLC, xác định góc φ; từ đó suy ra pha của i so với u. Thời điểm dòng cực đại giải từ điều kiện ωt+φ_i=2kπ.",
    "Tại hai tần số có cùng công suất: I=√(P/R) nên cùng I và cùng Z. Do đó |X_L−X_C| có cùng độ lớn ở hai phía cộng hưởng. Giải phương trình 2πfL−1/(2πfC)=±X rồi lấy hai nghiệm; trung bình hình học của hai tần số xấp xỉ f_0 trong mô hình chuẩn. R càng lớn thì dải thông càng rộng.",
    "Với tải P và điện áp truyền U, dòng I=P/(Ucosφ). Tổn hao đường dây P_loss=I²R=P²R/(U²cos²φ). Khi tăng U lên k lần, tổn hao giảm k² lần nếu P, cosφ, R giữ nguyên. Tính hiệu suất η=P_tải/(P_tải+P_loss)."
  ],
  [
    "e=Blv=0,5·0,4·5=1 V. I=e/R=2 A. Lực từ F=BIl=0,5·2·0,4=0,4 N cản chuyển động; kéo đều cần F_kéo=0,4 N. Công suất cơ P=F·v=0,4·5=2 W; công suất tỏa nhiệt I²R=4·0,5=2 W ⇒ bằng nhau nên năng lượng bảo toàn. Giải thích: theo định luật Lenz lực từ luôn cản chuyển động gây ra dòng cảm ứng.",
    "|e_tc|=L|ΔI|/Δt=0,2·4/0,1=8 V. W1=½LI1²=½·0,2·25=2,5 J; W2=½·0,2·1=0,1 J ⇒ độ giảm 2,4 J. Giải thích: năng lượng từ trường không tỉ lệ bậc nhất với I mà tỉ lệ I², nên không lấy ½L·ΔI².",
    "Đồ thị Φ(t) cho trực tiếp suất điện động ε=−N dΦ/dt. Trên đoạn tuyến tính, ε không đổi; độ dốc càng lớn thì |ε| càng lớn. Dấu âm theo Faraday–Lenz cho biết chiều dòng cảm ứng chống lại biến thiên từ thông.",
    "Chia quỹ đạo thành đoạn có dΦ/dt≠0 và đoạn từ thông không đổi. Chỉ đoạn có biến thiên từ thông mới có suất điện động cảm ứng. Lực điện từ F=BIl và công của lực kéo W_kéo phải bù năng lượng điện tỏa trên R cùng với biến thiên động năng.",
    "Máy phát có mô hình U=E−Ir. Từ điện áp không tải U_0≈E và dữ liệu có tải, r=(E−U)/I. Công suất tải P=UI, công suất cơ/đầu vào cần theo hiệu suất η=P_out/P_in. Tải cực đại theo mô hình đơn giản khi R_tải=r.",
    "Viết P_vào=P_hữu ích+P_tổn hao lõi+P_tổn hao đồng. Tổn hao đồng phụ thuộc I²R, nên khi tải tăng sẽ tăng nhanh. Hiệu suất η=P_ra/P_vào. Dùng dữ liệu U,I hai phía để tính P và đối chiếu cân bằng năng lượng."
  ],
  [
    "f=1/(2π√(LC))=1/(2π√(4×10^-6·10^-10))=1/(2π·2×10^-8)≈7,96×10^6 Hz. λ=c/f≈37,7 m. Với λ tỉ lệ √C: C′=C(60/37,7)²≈100·2,533≈253 pF ⇒ cần mắc song song thêm ΔC≈153 pF. Giải thích: tụ mắc song song thì điện dung cộng lại.",
    "I=P/(4πr²): tại 10 m I=100/(4π·100)≈0,0796 W/m²; tại 20 m I≈0,0199 W/m² (giảm 4 lần khi khoảng cách gấp đôi). P_thu=I·S=0,0199·0,5≈9,95 mW. Giải thích: năng lượng trải đều trên mặt cầu nên cường độ tỉ lệ nghịch bình phương khoảng cách.",
    "Mật độ công suất của nguồn đẳng hướng S=P/(4πr²). Vì vậy S_2/S_1=(r_1/r_2)². Công suất thu P_r≈S A_eff. Kiểm tra nếu anten có hệ số hướng tính thì phải đưa hệ số đó vào mô hình.",
    "Chênh lệch thời gian Δt tạo chênh lệch đường đi Δs=vΔt. Điều kiện giao thoa tăng cường Δs=kλ, triệt tiêu Δs=(k+1/2)λ trong mô hình hai đường truyền kết hợp.",
    "Mỗi trạm cho phương trình (x−x_i)²+(y−y_i)²=(ct_i)². Lấy hiệu hai phương trình để khử x²+y² rồi giải hệ tuyến tính trước, sau đó kiểm tra lại vào một phương trình khoảng cách. Nghiệm phải nằm trong miền hình học của hệ trạm.",
    "Mô hình suy giảm mũ I=I_0e^(−μx). Lấy ln(I/I_0)=−μx. Dùng hai hoặc nhiều điểm để suy ra μ từ độ dốc; chiều dày cần để I/I_0=0,01 là x=ln100/μ."
  ],
  [
    "N0=2/210·6,02×10^23≈5,73×10^21. λ=ln2/(138·86400)≈5,81×10^-8 s^-1 ⇒ H0=λN0≈3,33×10^14 Bq. 276 ngày=2T nên còn N0/4, số hạt phân rã=¾N0≈4,30×10^21 (tương ứng 1,5 g). Giải thích: phải đổi chu kì về giây khi tính hoạt độ theo Bq.",
    "Δm=2·1,0073+2·1,0087−4,0015=0,0305 u. W_lk=0,0305·931,5≈28,4 MeV. Năng lượng liên kết riêng=28,4/4≈7,10 MeV/nucleon. Giải thích: khối lượng hạt nhân nhỏ hơn tổng khối lượng nucleon; hạt nhân càng bền thì năng lượng liên kết riêng càng lớn.",
    "Viết A(t)=A_01 2^(−t/T_1)+A_02 2^(−t/T_2). Tại thời điểm hai đóng góp bằng nhau, giải phương trình A_01 2^(−t/T_1)=A_02 2^(−t/T_2). Có thể lấy log hai vế để giải t.",
    "Tổng năng lượng trong thời gian Δt là ∫A(t)E_0dt. Nếu hiệu suất hấp thụ η_abs thì năng lượng thực nhận E_abs=η_abs∫A(t)E_0dt. Với A(t)=A_0e^(−λt), tích phân từ 0 đến t là A_0(1−e^(−λt))/λ.",
    "Hoạt độ thực A_mẫu=A_đo−A_nền. Với số đếm N trong thời gian t, sai số thống kê xấp xỉ √N nên sai số tương đối giảm khi tăng thời gian đếm. Cần tách rõ sai số nền và sai số thống kê.",
    "Tuổi t=ln(A_0/A)/λ với λ=ln2/T_1/2. Nếu A có sai số tương đối δA/A thì độ nhạy của tuổi có thể ước lượng từ đạo hàm dt/dA=−1/(λA). Vì vậy khi A rất nhỏ, sai số tuổi tăng mạnh."
  ],
  [
    "A=1240/660≈1,88 eV; ε=1240/330≈3,76 eV (=6,01×10^-19 J). W_đmax=ε−A≈1,88 eV ⇒ U_h≈1,88 V. Số photon/s=3×10^-3/6,01×10^-19≈4,99×10^15; số electron/s=1%·4,99×10^15≈4,99×10^13 ⇒ I_bh≈4,99×10^13·1,6×10^-19≈8,0 μA. Giải thích: dòng bão hòa phụ thuộc số photon (công suất), còn U_h phụ thuộc bước sóng.",
    "ε=hc/λ=1,9875×10^-25/6,328×10^-7≈3,14×10^-19 J≈1,96 eV. N=P/ε=2×10^-3/3,14×10^-19≈6,37×10^15 photon/s. S=π(10^-3)²≈3,14×10^-6 m² ⇒ I=P/S≈637 W/m². Giải thích: cường độ nhỏ về công suất nhưng lớn vì tiết diện chùm rất nhỏ.",
    "Bước sóng không gây quang điện thỏa hc/λ>A. Bước sóng gây quang điện thỏa hc/λ≥A. Dùng điện thế hãm K_max=eU_h để tìm A=hc/λ−eU_h. Sau đó kiểm tra lại cả ba bước sóng.",
    "Bảo toàn năng lượng trong tán xạ photon phải viết theo mô hình đề cho. Năng lượng photon ban đầu E_i=hc/λ_i, sau tương tác E_f=hc/λ_f; phần chênh lệch chuyển thành động năng electron cùng với điều kiện bảo toàn động lượng nếu đề yêu cầu góc tán xạ.",
    "Năng lượng mỗi photon E=hc/λ. Số photon mỗi giây N=P/E=Pλ/(hc). Nếu hiệu suất lượng tử η_q thì số electron quang điện mỗi giây bằng η_qN. Dòng quang điện bão hòa I=eη_qN.",
    "Giữ tần số thì E photon không đổi, do đó K_max và U_h không đổi. Tăng cường độ làm tăng số photon tới mỗi giây, vì vậy dòng bão hòa tăng nếu hiệu suất lượng tử không đổi. Đây là cách phân biệt vai trò của tần số và cường độ."
  ],
  [
    "Số vạch=C(4,2)=6. Dài nhất khi chuyển 4→3: ΔE=13,6(1/9−1/16)≈0,661 eV ⇒ λ=1240/0,661≈1876 nm (hồng ngoại). Ngắn nhất khi chuyển 4→1: ΔE=13,6·15/16=12,75 eV ⇒ λ≈97,2 nm (tử ngoại). Giải thích: năng lượng photon càng lớn thì bước sóng càng ngắn.",
    "eU=hc/λ_min ⇒ λ_min=1240/20000=0,062 nm=6,2×10^-11 m. Công suất chùm electron=UI=20000·0,01=200 W ⇒ nhiệt 0,99·200=198 W nên anot cần tản nhiệt. Giải thích: bước sóng ngắn nhất ứng với toàn bộ động năng electron chuyển thành một photon.",
    "Ống tia X: electron được gia tốc qua U nên động năng cực đại eU. Photon tia X có năng lượng cực đại hc/λ_min=eU, do đó λ_min=hc/(eU)=1240/U(eV) nm. Nếu U=60 kV thì λ_min≈20,67 pm.",
    "Dùng công thức ΔE=hc/λ cho từng vạch. Với các mức E_n đã biết, ghép hiệu hai mức bằng năng lượng photon đo được. Vạch có λ lớn nhất trong cùng dãy tương ứng với chênh lệch năng lượng nhỏ nhất giữa các mức liên quan.",
    "Vẽ sơ đồ các mức. Với mỗi chuyển mức, ΔE=E_trên−E_dưới; photon có f=ΔE/h. Vì f tỉ lệ ΔE nên chuyển mức có độ chênh năng lượng lớn nhất phát photon tần số lớn nhất.",
    "Năng lượng electron nhận từ nguồn là E_điện=eUtổng cho mỗi electron; tổng công suất điện là UI. Bước sóng giới hạn dùng λ_min=hc/(eU). Hiệu suất tia X η=P_X/P_điện nếu dữ liệu cho công suất tia X; kiểm tra η<1."
  ]
];
