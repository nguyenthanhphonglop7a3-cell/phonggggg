/* Đúng/Sai: mỗi tình huống có ch (chương), title, context và 4 mệnh đề [nội dung, 1=Đúng/0=Sai, giải thích] */
const tfHard = [
  {
    "ch": 1,
    "title": "Nhiệt — đo nhiệt dung riêng của kim loại (có nhiệt lượng kế)",
    "context": "Nhiệt lượng kế có nhiệt dung 40 J/K chứa 0,20 kg nước ở 25°C. Thả vào 0,10 kg kim loại ở 100°C. Nhiệt độ cân bằng là 29,0°C. Lấy c_nước=4200 J/(kg·K).",
    "a": [
      [
        "Nhiệt lượng nước và nhiệt lượng kế thu vào là 3520 J.",
        1,
        "Q_thu=(0,2·4200+40)·(29−25)=880·4=3520 J."
      ],
      [
        "Nhiệt dung riêng của kim loại tính được xấp xỉ 496 J/(kg·K).",
        1,
        "Q_tỏa=0,1·c·(100−29)=3520 ⇒ c=3520/7,1≈496 J/(kg·K) (dùng kết quả ý a)."
      ],
      [
        "Nếu bỏ qua nhiệt dung của nhiệt lượng kế thì c tính được sẽ lớn hơn 496 J/(kg·K).",
        0,
        "Khi đó Q_thu=0,2·4200·4=3360 J nên c=3360/7,1≈473 J/(kg·K), nhỏ hơn."
      ],
      [
        "Nếu có tỏa nhiệt ra môi trường thì giá trị c thật của kim loại lớn hơn giá trị 496 J/(kg·K) đo được.",
        1,
        "Một phần nhiệt kim loại tỏa ra bị mất nên nhiệt thu đo được nhỏ hơn nhiệt tỏa thật; vì thế c đo thiên thấp."
      ]
    ]
  },
  {
    "ch": 2,
    "title": "Khí lí tưởng — chu trình A→B→C trên đồ thị p–V",
    "context": "Khí đơn nguyên tử, A(4×10^5 Pa; 1 L; 480 K) → B đẳng nhiệt đến V_B=4 L → C đẳng áp nén đến V_C=2 L. R=8,31 J/(mol·K).",
    "a": [
      [
        "Nhiệt độ ở trạng thái C là 240 K.",
        1,
        "p_B=1×10^5 Pa; p_CV_C=200 J, p_AV_A=400 J ⇒ T_C=480·200/400=240 K."
      ],
      [
        "Trong quá trình B→C khí nhận công 200 J.",
        1,
        "Nén đẳng áp: công khí nhận=p|ΔV|=10^5·2×10^-3=200 J."
      ],
      [
        "Trong quá trình A→B khí sinh công 400 J.",
        0,
        "Đẳng nhiệt: A=nRT·ln(V_B/V_A)=400·ln4≈554,5 J (400 J là pV, không phải công)."
      ],
      [
        "Trong quá trình B→C khí tỏa nhiệt 500 J.",
        1,
        "ΔU=1,5(p_CV_C−p_BV_B)=−300 J; công khí nhận 200 J nên Q=ΔU−A_nhận=−300−200=−500 J (tỏa 500 J)."
      ]
    ]
  },
  {
    "ch": 3,
    "title": "Từ trường — máy khối phổ phân tách hai đồng vị",
    "context": "Hai ion cùng điện tích +e, khối lượng 20 u và 22 u (1 u=1,66×10^-27 kg), tăng tốc từ nghỉ qua U=2000 V rồi bay vuông góc vào B=0,5 T.",
    "a": [
      [
        "Bán kính quỹ đạo của ion 20 u xấp xỉ 5,8 cm.",
        1,
        "r=(1/B)·√(2mU/q) với m=20·1,66×10^-27=3,32×10^-26 kg ⇒ r≈0,0576 m≈5,8 cm."
      ],
      [
        "Tỉ số bán kính hai ion r2/r1 bằng 1,1.",
        0,
        "r tỉ lệ √m nên r2/r1=√(22/20)≈1,049 (không phải 22/20)."
      ],
      [
        "Khoảng cách giữa hai vạch trên tấm ghi (tại điểm cuối nửa đường tròn) xấp xỉ 0,56 cm.",
        1,
        "Cách nhau 2(r2−r1)=2(6,04−5,76)≈0,56 cm."
      ],
      [
        "Tăng U lên gấp 4 lần thì khoảng cách giữa hai vạch cũng tăng gấp 4 lần.",
        0,
        "r tỉ lệ √U nên chỉ tăng gấp 2 lần."
      ]
    ]
  },
  {
    "ch": 4,
    "title": "Xoay chiều — thay đổi cảm kháng trong mạch RLC",
    "context": "Mạch RLC nối tiếp: R=30 Ω, Z_C=80 Ω, điện áp hiệu dụng U=120 V. Cho Z_L thay đổi.",
    "a": [
      [
        "Khi Z_L=40 Ω, cường độ hiệu dụng là 2,4 A.",
        1,
        "Z=√(30²+40²)=50 Ω; I=120/50=2,4 A."
      ],
      [
        "Khi Z_L=40 Ω, điện áp hai đầu mạch sớm pha hơn dòng điện góc 53°.",
        0,
        "Z_L<Z_C nên mạch có tính dung kháng: u trễ pha hơn i góc 53°."
      ],
      [
        "Công suất cực đại của mạch là 480 W, đạt khi Z_L=80 Ω.",
        1,
        "Cộng hưởng: P_max=U²/R=14400/30=480 W."
      ],
      [
        "Khi Z_L=120 Ω, công suất tiêu thụ bằng 172,8 W.",
        1,
        "|Z_L−Z_C|=40 Ω như trường hợp Z_L=40 Ω nên I=2,4 A và P=I²R=5,76·30=172,8 W."
      ]
    ]
  },
  {
    "ch": 5,
    "title": "Cảm ứng điện từ — thanh dẫn chuyển động chậm dần",
    "context": "Thanh dẫn dài 0,5 m, khối lượng 0,1 kg trượt không ma sát trên ray ngang, v_0=4 m/s, B=0,5 T thẳng đứng, điện trở toàn mạch 1 Ω (không có lực kéo).",
    "a": [
      [
        "Ngay lúc đầu suất điện động cảm ứng là 1 V.",
        1,
        "e=Blv=0,5·0,5·4=1 V."
      ],
      [
        "Gia tốc ban đầu của thanh có độ lớn 0,25 m/s².",
        0,
        "I=1 A; F=BIl=0,25 N; a=F/m=0,25/0,1=2,5 m/s²."
      ],
      [
        "Thanh chuyển động chậm dần đều với gia tốc có độ lớn 2,5 m/s².",
        0,
        "F=B²l²v/R tỉ lệ v nên gia tốc giảm dần khi v giảm, không đều."
      ],
      [
        "Tổng nhiệt tỏa ra trên điện trở cho đến khi thanh dừng là 0,8 J.",
        1,
        "Toàn bộ động năng ½mv0²=½·0,1·16=0,8 J biến thành nhiệt."
      ]
    ]
  },
  {
    "ch": 6,
    "title": "Sóng điện từ — mạch chọn sóng của máy thu",
    "context": "Mạch LC có L=2 μH, tụ xoay C biến thiên từ 50 pF đến 200 pF; c=3×10^8 m/s; λ=2πc√(LC).",
    "a": [
      [
        "Bước sóng nhỏ nhất máy thu được xấp xỉ 18,8 m.",
        1,
        "λ_min=2π·3×10^8·√(2×10^-6·50×10^-12)≈18,8 m."
      ],
      [
        "Dải tần số thu được từ 15,9 MHz đến 31,8 MHz.",
        0,
        "f=c/λ: từ 7,96 MHz (λ≈37,7 m) đến 15,9 MHz (λ≈18,8 m)."
      ],
      [
        "Máy thu được sóng 30 m khi C≈127 pF.",
        1,
        "C=(λ/2πc)²/L=(30/1,885×10^9)²/(2×10^-6)≈1,27×10^-10 F, nằm trong dải 50–200 pF."
      ],
      [
        "Máy thu được sóng 40 m nếu vặn tụ đến 200 pF.",
        0,
        "Ở 200 pF λ_max≈37,7 m<40 m; cần C≈225 pF, vượt giới hạn."
      ]
    ]
  },
  {
    "ch": 7,
    "title": "Hạt nhân — phân tích số liệu đếm xung của nguồn phóng xạ",
    "context": "Số xung đếm/phút (đã gồm nền 50 xung/phút): t=0: 1650; t=8 ngày: 850; t=16 ngày: 450; t=24 ngày: 250.",
    "a": [
      [
        "Sau khi trừ nền, số xung nguồn ở t=16 ngày là 400 xung/phút.",
        1,
        "450−50=400 xung/phút."
      ],
      [
        "Nếu không trừ nền, chu kì bán rã tính từ số liệu t=0 và t=8 ngày vẫn đúng 8 ngày.",
        0,
        "T=8ln2/ln(1650/850)≈8,36 ngày; phải trừ nền (1600→800 mới ra 8 ngày)."
      ],
      [
        "Hoạt độ nguồn ở t=24 ngày còn 15,2% hoạt độ ban đầu.",
        0,
        "Sau trừ nền: 200/1600=12,5% (15,2% là 250/1650 chưa trừ nền)."
      ],
      [
        "Hằng số phân rã của chất này xấp xỉ 0,087 ngày^-1.",
        1,
        "T=8 ngày ⇒ λ=ln2/8≈0,0866 ngày^-1."
      ]
    ]
  },
  {
    "ch": 8,
    "title": "Lượng tử ánh sáng — số liệu hiệu điện thế hãm",
    "context": "Kim loại có công thoát A=2,0 eV. Lấy hc=1240 eV·nm, h=6,625×10^-34 J·s, e=1,6×10^-19 C. Đo U_h với hai bước sóng: 400 nm và 300 nm.",
    "a": [
      [
        "Với λ=300 nm, hiệu điện thế hãm là 3,10 V.",
        0,
        "eU_h=ε−A=4,13−2,0≈2,13 eV nên U_h≈2,13 V (3,10 eV là năng lượng photon 400 nm)."
      ],
      [
        "Giới hạn quang điện của kim loại là 620 nm.",
        1,
        "λ0=hc/A=1240/2,0=620 nm."
      ],
      [
        "Ánh sáng tần số 4×10^14 Hz gây quang điện nếu cường độ đủ lớn.",
        0,
        "f=4×10^14 Hz ứng λ=750 nm>620 nm: năng lượng photon 1,66 eV<A, tăng cường độ không giúp ích."
      ],
      [
        "Đồ thị U_h theo tần số f là đường thẳng có hệ số góc xấp xỉ 4,14×10^-15 V·s.",
        1,
        "eU_h=hf−A ⇒ U_h=(h/e)f−A/e; h/e≈4,14×10^-15 V·s."
      ]
    ]
  },
  {
    "ch": 9,
    "title": "Nguyên tử hiđrô — kích thích bằng chùm electron",
    "context": "Nguyên tử hiđrô ở trạng thái cơ bản bị bắn bởi electron có động năng 12,5 eV. E_n=−13,6/n² eV; hc=1240 eV·nm.",
    "a": [
      [
        "Nguyên tử có thể được kích thích lên mức n=3 nhưng không lên được n=4.",
        1,
        "Cần 12,09 eV cho n=3 (≤12,5 eV) và 12,75 eV cho n=4 (>12,5 eV)."
      ],
      [
        "Khi trở về trạng thái cơ bản, có thể phát tối đa 6 vạch phổ.",
        0,
        "Chỉ lên tới n=3 nên tối đa C(3,2)=3 vạch (3→2, 3→1, 2→1)."
      ],
      [
        "Trong các vạch phát ra có 2 vạch nằm trong vùng tử ngoại.",
        1,
        "3→1 (≈102,6 nm) và 2→1 (≈121,6 nm) là tử ngoại; 3→2 (≈656 nm) là ánh sáng đỏ."
      ],
      [
        "Nếu thay electron bằng photon có năng lượng 12,5 eV thì nguyên tử vẫn hấp thụ để lên n=3.",
        0,
        "Photon chỉ bị hấp thụ khi năng lượng đúng bằng hiệu hai mức (12,09 eV); electron thì có thể chuyển một phần động năng."
      ]
    ]
  },
  {
    "ch": 1,
    "title": "Nhiệt — phân tích bảng đun nóng đá (có chuyển thể)",
    "context": "Đun 0,20 kg đá bằng bếp có công suất nhiệt hữu ích không đổi. Số liệu: t=0: −20°C; t=84 s: 0°C (bắt đầu tan); t=752 s: 0°C (vừa tan hết); t=1172 s: 50°C. Cho c_đá=2100 J/(kg·K).",
    "a": [
      [
        "Công suất nhiệt hữu ích của bếp là 100 W.",
        1,
        "Giai đoạn 0–84 s chỉ làm đá nóng lên: Q=0,2·2100·20=8400 J ⇒ P=8400/84=100 W."
      ],
      [
        "Dùng khoảng thời gian từ 0 đến 752 s để tính, nhiệt nóng chảy riêng của đá là 3,76×10^5 J/kg.",
        0,
        "Chỉ tính giai đoạn tan 84→752 s (668 s): λ=100·668/0,2=3,34×10^5 J/kg; 3,76×10^5 J/kg là do tính nhầm cả đoạn đá nóng lên."
      ],
      [
        "Nhiệt dung riêng của nước tính được từ số liệu là 4200 J/(kg·K).",
        1,
        "Giai đoạn 752→1172 s (420 s): c=P·t/(m·Δt)=100·420/(0,2·50)=4200 J/(kg·K)."
      ],
      [
        "Thời gian để nước từ 50°C đun đến 100°C tiếp theo là 840 s.",
        0,
        "Q=0,2·4200·50=42000 J ⇒ t=420 s (840 s là do nhầm Δt=100°C)."
      ]
    ]
  },
  {
    "ch": 2,
    "title": "Khí lí tưởng — hai bình nối nhau bằng ống",
    "context": "Bình A (2 L) chứa khí ở 3×10^5 Pa, 300 K. Bình B (3 L) chứa cùng loại khí ở 1×10^5 Pa, 400 K. Mở van nối hai bình; sau đó toàn bộ khí ở nhiệt độ 350 K.",
    "a": [
      [
        "Số mol khí ở hai bình lúc đầu bằng nhau.",
        0,
        "n_A=pV/(RT)=600/(300R)=2/R; n_B=300/(400R)=0,75/R ⇒ n_A lớn hơn nhiều."
      ],
      [
        "Áp suất khí sau khi mở van xấp xỉ 1,925×10^5 Pa.",
        1,
        "n=2,75/R; p=nRT/V=2,75·350/(5×10^-3)=1,925×10^5 Pa."
      ],
      [
        "Áp suất cuối bằng trung bình cộng hai áp suất đầu, tức 2×10^5 Pa.",
        0,
        "Không thể lấy trung bình cộng vì thể tích và nhiệt độ hai bình khác nhau."
      ],
      [
        "Nếu nhiệt độ cuối là 300 K thì áp suất cuối bằng 1,65×10^5 Pa.",
        1,
        "p=nRT/V=2,75·300/(5×10^-3)=1,65×10^5 Pa."
      ]
    ]
  },
  {
    "ch": 3,
    "title": "Từ trường — thanh dẫn cân bằng trên mặt phẳng nghiêng",
    "context": "Thanh dẫn dài 0,4 m, khối lượng 20 g đặt ngang trên hai ray nghiêng α=30°, bỏ qua ma sát; g=9,8 m/s². Từ trường đều B=0,5 T hướng thẳng đứng. Thanh cân bằng nhờ dòng I.",
    "a": [
      [
        "Cường độ dòng điện cân bằng xấp xỉ 0,57 A.",
        1,
        "F nằm ngang: Fcosα=mg sinα ⇒ BIl=mg tanα ⇒ I=0,196·0,577/0,2≈0,57 A."
      ],
      [
        "Phản lực của ray lên thanh bằng mg·cosα≈0,17 N.",
        0,
        "Phản lực còn chịu thêm thành phần của lực từ: N=mg/cosα≈0,226 N."
      ],
      [
        "Nếu từ trường vuông góc với mặt phẳng ray thì dòng cân bằng giảm còn 0,49 A.",
        1,
        "Lực từ song song mặt ray: BIl=mg sinα ⇒ I=0,098/0,2=0,49 A."
      ],
      [
        "Cường độ dòng cân bằng không phụ thuộc khối lượng thanh.",
        0,
        "I=mg tanα/(Bl) tỉ lệ với khối lượng thanh."
      ]
    ]
  },
  {
    "ch": 4,
    "title": "Xoay chiều — hai tần số cho cùng cường độ",
    "context": "Mạch RLC nối tiếp: R=100 Ω, L=1/π H, U=200 V không đổi, tần số f thay đổi. Biết cường độ hiệu dụng khi f=50 Hz và f=200 Hz bằng nhau.",
    "a": [
      [
        "Tần số cộng hưởng của mạch là 100 Hz.",
        1,
        "f1·f2=f0² ⇒ f0=√(50·200)=100 Hz."
      ],
      [
        "Điện dung của tụ điện là 79,6 μF.",
        0,
        "C=1/(ω0²L)=1/(40000π)≈7,96×10^-6 F=7,96 μF."
      ],
      [
        "Khi f=50 Hz cường độ hiệu dụng là 0,632 A.",
        1,
        "Z_L=100 Ω; Z_C=400 Ω; Z=√(100²+300²)≈316 Ω ⇒ I=200/316≈0,632 A."
      ],
      [
        "Ở cả f=50 Hz và f=200 Hz mạch đều có u sớm pha hơn i với cùng hệ số công suất 0,316.",
        0,
        "cosφ=100/316=0,316 ở cả hai tần số, nhưng ở 50 Hz (Z_C>Z_L) u trễ pha hơn i; chỉ ở 200 Hz u mới sớm pha hơn i."
      ]
    ]
  },
  {
    "ch": 5,
    "title": "Cảm ứng điện từ — từ thông biến thiên theo thời gian",
    "context": "Cuộn dây N=50 vòng, từ thông qua mỗi vòng Φ=4×10^-3·cos(100πt) Wb, nối với điện trở R=10 Ω (bỏ qua điện trở cuộn dây).",
    "a": [
      [
        "Suất điện động cực đại trong cuộn dây xấp xỉ 62,8 V.",
        1,
        "E0=NΦ0ω=50·4×10^-3·100π≈62,8 V."
      ],
      [
        "Suất điện động có độ lớn cực đại tại thời điểm từ thông có độ lớn cực đại.",
        0,
        "e=−NdΦ/dt tỉ lệ với sinωt: cực đại khi Φ=0 (e và Φ lệch pha π/2)."
      ],
      [
        "Công suất tỏa nhiệt trung bình trên R xấp xỉ 395 W.",
        0,
        "P=I²R với I=I0/√2: P=(6,28²/2)·10≈197 W (395 W là do dùng I0²R)."
      ],
      [
        "Tại t=1/600 s suất điện động có giá trị xấp xỉ 31,4 V.",
        1,
        "ωt=π/6 ⇒ e=E0 sin(π/6)=62,8·0,5=31,4 V."
      ]
    ]
  },
  {
    "ch": 6,
    "title": "Sóng điện từ — xác định vị trí bằng độ trễ tín hiệu",
    "context": "Hai trạm phát A, B cách nhau 30 km phát đồng thời một tín hiệu vô tuyến (c=3×10^8 m/s). Máy thu nhận tín hiệu từ A trễ 60 μs và từ B trễ 140 μs.",
    "a": [
      [
        "Khoảng cách từ máy thu đến trạm A là 18 km.",
        1,
        "d_A=ct=3×10^8·60×10^-6=18 km (và d_B=42 km)."
      ],
      [
        "Máy thu nằm trên đường thẳng AB.",
        0,
        "Nếu thẳng hàng thì d_A+d_B=30 km hoặc |d_B−d_A|=30 km; ở đây 18+42=60 km và 42−18=24 km nên không thẳng hàng."
      ],
      [
        "Nếu máy thu nằm trên đường thẳng AB ngoài đoạn AB (phía A) thì tín hiệu từ B đến trễ hơn từ A đúng 100 μs.",
        1,
        "Chênh lệch quãng đường =AB=30 km ⇒ Δt=30000/3×10^8=100 μs."
      ],
      [
        "Nếu đồng hồ máy thu chạy lệch làm cả hai thời gian trễ cùng tăng thêm 10 μs thì chênh lệch d_B−d_A bị sai 3 km.",
        0,
        "Hiệu d_B−d_A không đổi (24 km) vì sai số cộng chung bị triệt tiêu; chỉ khoảng cách tuyệt đối mỗi trạm sai thêm 3 km."
      ]
    ]
  },
  {
    "ch": 7,
    "title": "Hạt nhân — năng lượng liên kết của đơteri",
    "context": "Hạt nhân đơteri (1 proton + 1 nơtron) có m_D=2,0136 u; m_p=1,0073 u; m_n=1,0087 u; 1 u=931,5 MeV/c².",
    "a": [
      [
        "Độ hụt khối của đơteri là 0,0024 u.",
        1,
        "Δm=1,0073+1,0087−2,0136=0,0024 u."
      ],
      [
        "Năng lượng liên kết của đơteri xấp xỉ 22,4 MeV.",
        0,
        "W_lk=0,0024·931,5≈2,24 MeV (22,4 MeV là sai bậc độ lớn)."
      ],
      [
        "Năng lượng liên kết riêng của đơteri khoảng 1,12 MeV/nucleon.",
        1,
        "2,24/2=1,12 MeV/nucleon."
      ],
      [
        "Hạt nhân có năng lượng liên kết riêng càng lớn thì càng kém bền vững.",
        0,
        "Năng lượng liên kết riêng càng lớn thì hạt nhân càng bền."
      ]
    ]
  },
  {
    "ch": 8,
    "title": "Lượng tử ánh sáng — năng lượng photon và quang điện",
    "context": "Chiếu ánh sáng bước sóng 500 nm lên kim loại có công thoát A=2,0 eV. Lấy hc=1240 eV·nm.",
    "a": [
      [
        "Năng lượng mỗi photon là 2,48 eV.",
        1,
        "ε=1240/500=2,48 eV."
      ],
      [
        "Photon ánh sáng đỏ 700 nm có năng lượng lớn hơn photon 500 nm.",
        0,
        "ε tỉ lệ nghịch với λ nên photon 700 nm (1,77 eV) có năng lượng nhỏ hơn."
      ],
      [
        "Động năng ban đầu cực đại của quang electron là 0,48 eV.",
        1,
        "W=ε−A=2,48−2,0=0,48 eV."
      ],
      [
        "Dùng ánh sáng 700 nm nhưng cường độ rất lớn thì vẫn gây ra quang điện.",
        0,
        "ε=1,77 eV<A nên không xảy ra quang điện dù tăng cường độ; mỗi electron chỉ hấp thụ 1 photon."
      ]
    ]
  },
  {
    "ch": 9,
    "title": "Nguyên tử hiện đại — ống tia X",
    "context": "Ống tia X hoạt động ở hiệu điện thế 40 kV. Lấy hc=1240 eV·nm.",
    "a": [
      [
        "Bước sóng ngắn nhất của tia X phát ra là 0,031 nm.",
        1,
        "λ_min=hc/(eU)=1240/40000=0,031 nm."
      ],
      [
        "Tăng hiệu điện thế lên gấp đôi thì bước sóng ngắn nhất tăng gấp đôi.",
        0,
        "λ_min tỉ lệ nghịch với U nên giảm một nửa."
      ],
      [
        "Tăng dòng điện qua ống (U không đổi) làm bước sóng ngắn nhất giảm.",
        0,
        "λ_min chỉ phụ thuộc U; tăng dòng chỉ tăng số electron nên tăng cường độ chùm tia."
      ],
      [
        "Tia X là sóng điện từ nên không bị lệch trong điện trường.",
        1,
        "Tia X không mang điện nên không bị điện trường, từ trường làm lệch."
      ]
    ]
  },
  {
    "ch": 1,
    "title": "Nhiệt — đo nhiệt hóa hơi riêng của nước bằng điện",
    "context": "Dây điện trở nhúng trong bình nước đang sôi ở 100°C, hiệu điện thế 12 V, dòng 5 A. Trong 300 s khối lượng nước trong bình giảm 6,0 g (coi toàn bộ nhiệt hữu ích chỉ dùng để hóa hơi). Giá trị chuẩn L=2,26×10^6 J/kg.",
    "a": [
      [
        "Điện năng điện trở tiêu thụ trong 300 s là 18 kJ.",
        1,
        "P=UI=60 W; A=Pt=60·300=18000 J."
      ],
      [
        "Nhiệt hóa hơi riêng đo được xấp xỉ 3,0×10^6 J/kg.",
        1,
        "L=Q/m=18000/0,006=3,0×10^6 J/kg."
      ],
      [
        "Giá trị đo được nhỏ hơn giá trị chuẩn.",
        0,
        "3,0×10^6>2,26×10^6: một phần nhiệt tỏa ra môi trường nên khối lượng hóa hơi nhỏ hơn dự kiến, L đo ra lớn hơn."
      ],
      [
        "Nếu dùng hiệu điện thế 24 V với cùng điện trở thì khối lượng nước hóa hơi trong 300 s tăng gấp đôi.",
        0,
        "P=U²/R tỉ lệ U² nên tăng 4 lần (R=2,4 Ω; P=240 W)."
      ]
    ]
  },
  {
    "ch": 1,
    "title": "Nhiệt — định luật I nhiệt động lực học qua hai quá trình",
    "context": "Khí trong xilanh: quá trình 1, khí nhận nhiệt 600 J và sinh công 250 J. Quá trình 2 ngay sau đó, khí bị nén: nhận công 400 J và tỏa nhiệt 450 J.",
    "a": [
      [
        "Trong quá trình 1, nội năng khí tăng 350 J.",
        1,
        "ΔU=Q+A=600−250=350 J (A=−250 J vì khí sinh công)."
      ],
      [
        "Trong quá trình 2 khí nhận công nên nhiệt độ khí tăng.",
        0,
        "ΔU2=400−450=−50 J<0 nên nhiệt độ giảm dù khí nhận công."
      ],
      [
        "Sau cả hai quá trình nội năng khí tăng 300 J.",
        1,
        "ΔU=350+(−50)=300 J."
      ],
      [
        "Công khí nhận ròng trong cả hai quá trình là −150 J.",
        0,
        "A ròng nhận=−250+400=+150 J (khí nhận công ròng), nhiệt ròng 600−450=150 J ⇒ ΔU=300 J."
      ]
    ]
  },
  {
    "title": "Nhiệt — đá thả vào nước: xác định trạng thái cuối trước khi tính",
    "context": "Bình cách nhiệt (bỏ qua nhiệt dung bình) chứa 0,30 kg nước ở 20°C. Thả vào 0,20 kg nước đá ở −20°C. Cho c_đá=2100; c_nước=4200 J/(kg·K); λ=3,34×10^5 J/kg.",
    "a": [
      [
        "Khi cân bằng, nhiệt độ của hệ là 0°C và trong bình còn cả nước lẫn đá.",
        1,
        "Đá cần 0,2·2100·20=8400 J để lên 0°C; nước tỏa tối đa 0,3·4200·20=25200 J khi xuống 0°C nhưng để tan hết đá cần thêm 66800 J; 25200<8400+66800 nên đá không tan hết."
      ],
      [
        "Khối lượng đá tan ra xấp xỉ 50 g.",
        1,
        "Nhiệt dư sau khi đá lên 0°C: 25200−8400=16800 J ⇒ m_tan=16800/3,34×10^5≈0,0503 kg."
      ],
      [
        "Khối lượng đá còn lại trong bình xấp xỉ 100 g.",
        0,
        "Đá còn lại=200−50,3≈149,7 g (≈150 g)."
      ],
      [
        "Để đá tan hết mà nhiệt độ cuối vẫn là 0°C, nhiệt độ ban đầu của 0,30 kg nước phải xấp xỉ 59,7°C.",
        1,
        "Cần 8400+66800=75200 J=0,3·4200·T ⇒ T≈59,7°C; cao hơn thì t cuối>0°C, thấp hơn thì còn đá."
      ]
    ],
    "ch": 1
  },
  {
    "ch": 1,
    "title": "Nhiệt — phân tích đồ thị đun nóng một chất rắn",
    "context": "Bếp cấp nhiệt hữu ích 200 W cho 0,50 kg chất X. Số liệu: rắn từ 20°C đến 80°C mất 150 s; nóng chảy hoàn toàn ở 80°C mất 600 s; lỏng từ 80°C đến 120°C mất 160 s.",
    "a": [
      [
        "Nhiệt dung riêng của X ở thể rắn là 1000 J/(kg·K).",
        1,
        "Q=200·150=30000 J=0,5·c·60 ⇒ c=1000 J/(kg·K)."
      ],
      [
        "Nhiệt nóng chảy riêng của X là 1,2×10^5 J/kg.",
        0,
        "λ=Q/m=200·600/0,5=2,4×10^5 J/kg (1,2×10^5 J là do quên chia cho khối lượng)."
      ],
      [
        "Nhiệt dung riêng của X ở thể lỏng lớn hơn ở thể rắn.",
        1,
        "c_lỏng=200·160/(0,5·40)=1600 J/(kg·K)>1000 J/(kg·K)."
      ],
      [
        "Trong giai đoạn nóng chảy nhiệt độ không đổi nên nhiệt cung cấp không làm tăng nội năng của X.",
        0,
        "Nhiệt dùng để phá cấu trúc tinh thể, làm tăng thế năng phân tử nên nội năng vẫn tăng."
      ]
    ]
  },
  {
    "title": "Nhiệt — thả nhiều vật liên tiếp vào nhiệt lượng kế",
    "context": "Nhiệt lượng kế chứa nước, tổng nhiệt dung của nước và bình là W, ban đầu ở 20°C. Thả vào một vật kim loại nhiệt dung k, nhiệt độ 100°C thì cân bằng ở 24°C. Sau đó thả tiếp vật thứ hai giống hệt (cũng ở 100°C), rồi vật thứ ba. Bỏ qua mất nhiệt.",
    "a": [
      [
        "Nhiệt dung W của nước và bình bằng 19 lần nhiệt dung k của một vật.",
        1,
        "k(100−24)=W(24−20) ⇒ 76k=4W ⇒ W=19k."
      ],
      [
        "Sau khi thả vật thứ hai, nhiệt độ cân bằng xấp xỉ 27,6°C.",
        1,
        "k(100−t2)=(W+k)(t2−24)=20k(t2−24) ⇒ t2=(100+480)/21≈27,6°C."
      ],
      [
        "Sau khi thả vật thứ ba, nhiệt độ cân bằng xấp xỉ 31,5°C.",
        0,
        "(W+2k)=21k: t3=(100+21·27,6)/22≈30,9°C."
      ],
      [
        "Mỗi lần thả thêm một vật, nhiệt độ cân bằng tăng thêm đúng 4°C.",
        0,
        "Độ tăng giảm dần: 4°C, 3,6°C, 3,3°C... vì hệ ngày càng nóng nên hiệu nhiệt độ với vật mới nhỏ dần."
      ]
    ],
    "ch": 1
  },
  {
    "ch": 1,
    "title": "Nhiệt — hơi nước ngưng tụ vào nước lạnh",
    "context": "Dẫn 10 g hơi nước ở 100°C vào 0,40 kg nước ở 20°C đựng trong bình có nhiệt dung 100 J/K. Cho L=2,26×10^6 J/kg, c=4200 J/(kg·K); bỏ qua hao phí.",
    "a": [
      [
        "Nhiệt lượng 10 g hơi tỏa ra khi ngưng tụ hoàn toàn thành nước 100°C là 22,6 kJ.",
        1,
        "Q=mL=0,01·2,26×10^6=22600 J."
      ],
      [
        "Nhiệt độ cân bằng của hệ xấp xỉ 34,2°C.",
        1,
        "22600+0,01·4200(100−t)=(0,4·4200+100)(t−20) ⇒ t≈34,2°C."
      ],
      [
        "Nếu bỏ qua sự ngưng tụ (coi là 10 g nước ở 100°C) thì nhiệt độ cân bằng xấp xỉ 21,8°C.",
        1,
        "42(100−t)=1780(t−20) ⇒ t≈21,8°C: thấp hơn nhiều vì thiếu 22,6 kJ ẩn nhiệt."
      ],
      [
        "Hơi nước 100°C gây bỏng nặng hơn nước 100°C cùng khối lượng vì hơi có nhiệt độ cao hơn.",
        0,
        "Cùng 100°C; hơi gây bỏng nặng do tỏa thêm nhiệt ngưng tụ (mL) rất lớn."
      ]
    ]
  },
  {
    "ch": 2,
    "title": "Khí lí tưởng — thí nghiệm định luật Boyle",
    "context": "Nén khí chậm trong xilanh ở nhiệt độ không đổi, đo (p; V): (1,0×10^5 Pa; 6,0 L), (1,5×10^5 Pa; 4,0 L), (2,0×10^5 Pa; 3,0 L), (2,4×10^5 Pa; 2,5 L).",
    "a": [
      [
        "Tích pV gần như không đổi và bằng khoảng 600 J.",
        1,
        "1,0×10^5·6×10^-3=600 J; các cặp còn lại cũng ra 600 J."
      ],
      [
        "Đồ thị p theo V là một đường thẳng.",
        0,
        "p∝1/V nên đồ thị p–V là hypebol; đồ thị p theo 1/V mới là đường thẳng."
      ],
      [
        "Khi p=3,0×10^5 Pa thì V=2,0 L.",
        1,
        "V=600/(3×10^5)=2×10^-3 m³=2,0 L."
      ],
      [
        "Nếu nén rất nhanh (không kịp trao đổi nhiệt) thì tích pV sau nén nhỏ hơn 600 J.",
        0,
        "Nén nhanh nhiệt độ tăng nên pV>600 J."
      ]
    ]
  },
  {
    "ch": 2,
    "title": "Khí lí tưởng — chu trình với đoạn đẳng nhiệt",
    "context": "Khí đơn nguyên tử: A(1×10^5 Pa; 4 L; 300 K) → B đẳng tích đến 3×10^5 Pa → C đẳng nhiệt giãn đến 12 L → A đẳng áp nén về 4 L.",
    "a": [
      [
        "Nhiệt độ ở trạng thái B là 900 K.",
        1,
        "Đẳng tích: T_B=T_A·p_B/p_A=900 K."
      ],
      [
        "Công khí sinh trong quá trình B→C xấp xỉ 1318 J.",
        1,
        "A=p_BV_B·ln(V_C/V_B)=1200·ln3≈1318 J."
      ],
      [
        "Công khí nhận trong quá trình C→A là 1200 J.",
        0,
        "Nén đẳng áp: p|ΔV|=10^5·8×10^-3=800 J."
      ],
      [
        "Trong quá trình C→A khí đơn nguyên tử tỏa nhiệt 2000 J.",
        1,
        "ΔU=1,5(p_AV_A−p_CV_C)=1,5(400−1200)=−1200 J; công nhận 800 J ⇒ Q=−1200−800=−2000 J."
      ]
    ]
  },
  {
    "ch": 2,
    "title": "Khí lí tưởng — mô hình động học phân tử",
    "context": "Khí heli (m=4 u=6,64×10^-27 kg) ở 300 K. Lấy k=1,38×10^-23 J/K. Neon có khối lượng 20 u.",
    "a": [
      [
        "Động năng tịnh tiến trung bình của một nguyên tử He xấp xỉ 6,2×10^-21 J.",
        1,
        "E=(3/2)kT=1,5·1,38×10^-23·300≈6,2×10^-21 J."
      ],
      [
        "Tốc độ căn quân phương của He xấp xỉ 1,37 km/s.",
        1,
        "v=√(3kT/m)=√(3·1,38×10^-23·300/6,64×10^-27)≈1368 m/s."
      ],
      [
        "Nếu nhiệt độ tăng từ 300 K lên 1200 K thì v căn quân phương tăng gấp 4 lần.",
        0,
        "v tỉ lệ √T nên chỉ tăng gấp 2 lần."
      ],
      [
        "Ở cùng 300 K, He và Ne có cùng động năng trung bình nhưng v căn quân phương của Ne nhỏ hơn √5 lần so với He.",
        1,
        "E chỉ phụ thuộc T; v∝1/√m nên v_Ne/v_He=√(4/20)=1/√5."
      ]
    ]
  },
  {
    "ch": 2,
    "title": "Khí lí tưởng — bọt khí nổi từ đáy hồ",
    "context": "Bọt khí ở đáy hồ sâu 20 m (nhiệt độ đáy 7°C) nổi lên mặt hồ ở 27°C. Lấy p0=1×10^5 Pa; ρg=1×10^4 Pa/m; coi lượng khí không đổi.",
    "a": [
      [
        "Áp suất ở đáy hồ là 3×10^5 Pa.",
        1,
        "p=p0+ρgh=10^5+10^4·20=3×10^5 Pa."
      ],
      [
        "Thể tích bọt khi lên mặt hồ gấp khoảng 3,21 lần lúc ở đáy.",
        1,
        "V2/V1=p1T2/(p2T1)=3·300/280≈3,21."
      ],
      [
        "So với trường hợp coi nhiệt độ không đổi, chênh lệch tỉ số thể tích do thay đổi nhiệt độ nhỏ hơn 1%.",
        0,
        "Đẳng nhiệt cho tỉ số 3,00; thực tế 3,21, chênh khoảng 7%."
      ],
      [
        "Khối lượng khí trong bọt giảm dần khi bọt nổi lên.",
        0,
        "Lượng khí trong bọt không đổi; chỉ p, V, T thay đổi."
      ]
    ]
  },
  {
    "ch": 2,
    "title": "Khí lí tưởng — hiệu suất chu trình hình chữ nhật",
    "context": "Khí đơn nguyên tử thực hiện chu trình A(1×10^5 Pa; 2 L) → B(3×10^5 Pa; 2 L) → C(3×10^5 Pa; 6 L) → D(1×10^5 Pa; 6 L) → A.",
    "a": [
      [
        "Công khí sinh trong một chu trình là 800 J.",
        1,
        "A=(p_B−p_A)(V_C−V_A)=2×10^5·4×10^-3=800 J."
      ],
      [
        "Nhiệt lượng khí nhận được trong một chu trình là 3600 J.",
        1,
        "A→B: 1,5·ΔpV_A=600 J; B→C: 2,5p_BΔV=3000 J; tổng 3600 J."
      ],
      [
        "Hiệu suất của chu trình xấp xỉ 22,2%.",
        1,
        "H=A/Q_nhận=800/3600≈22,2%."
      ],
      [
        "Hiệu suất Carnot giữa nhiệt độ cực đại và cực tiểu của chu trình là 66,7%.",
        0,
        "T∝pV: T_min tại A (200 J), T_max tại C (1800 J) ⇒ H=1−200/1800≈88,9%."
      ]
    ]
  },
  {
    "ch": 2,
    "title": "Khí lí tưởng — khí nén bởi pittông có khối lượng",
    "context": "Xilanh đứng, pittông khối lượng 10 kg, tiết diện 50 cm², p0=1×10^5 Pa, g=9,8 m/s². Cột khí cao 20 cm ở 300 K, được đun nóng đẳng áp lên 360 K.",
    "a": [
      [
        "Áp suất khí trong xilanh xấp xỉ 1,196×10^5 Pa.",
        1,
        "p=p0+Mg/S=10^5+98/(5×10^-3)=1,196×10^5 Pa."
      ],
      [
        "Sau khi đun, cột khí cao 24 cm.",
        1,
        "Đẳng áp: h2=h1·T2/T1=20·360/300=24 cm."
      ],
      [
        "Công khí sinh khi đun xấp xỉ 2,4 J.",
        0,
        "A=pΔV=1,196×10^5·50×10^-4·0,04≈23,9 J (2,4 J sai bậc độ lớn)."
      ],
      [
        "Nếu giữ pittông cố định (thể tích không đổi) rồi đun từ 300 K lên 360 K thì áp suất khí tăng lên khoảng 1,435×10^5 Pa.",
        1,
        "Đẳng tích: p2=p1·T2/T1=1,196×10^5·1,2≈1,435×10^5 Pa."
      ]
    ]
  }
];
