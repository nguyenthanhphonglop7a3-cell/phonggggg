/* Trả lời ngắn: 10 câu/chương */
const shortHardByChapter = [
[
{p:'Một bình cách nhiệt chứa 0,40 kg nước ở 30°C. Thả vào 0,15 kg nước đá ở −10°C. Cho c_nước=4200 J/(kg·K), c_đá=2100 J/(kg·K), λ=334 kJ/kg. Bỏ qua nhiệt dung bình. Tính nhiệt độ cân bằng cuối cùng (°C), làm tròn 0,01°C.',ans:0.13,tol:0.02,a:'Nước tỏa tối đa đến 0°C: 0,40·4200·30=50 400 J. Đá cần 0,15·2100·10+0,15·334000=53 250 J nếu tan hết, nên đá tan hết và còn 3 150 J để làm nóng 0,55 kg nước. ΔT=3150/(0,55·4200)=0,136°C ⇒ T≈0,14°C.'},
{p:'Một vật kim loại 0,10 kg ở 150°C được thả vào 0,20 kg nước ở 25°C trong nhiệt lượng kế lí tưởng. Nhiệt độ cân bằng 35°C. Cho c_nước=4200 J/(kg·K). Tính nhiệt dung riêng của kim loại theo J/(kg·K), làm tròn đến đơn vị.',ans:730,tol:1,a:'Nhiệt nước thu: 0,20·4200·10=8400 J. Kim loại tỏa: 0,10·c·(150−35). Suy ra c=8400/(11,5)=730,43 J/(kg·K) ≈730.'},
{p:'Một dây đốt công suất 500 W nung chảy hoàn toàn 0,25 kg nước đá ở 0°C trong 240 s. Chỉ 80% điện năng thực sự truyền cho nước đá. Tính nhiệt nóng chảy riêng λ theo kJ/kg.',ans:384,tol:0.5,a:'Q_hữu ích=0,80·500·240=96 000 J. λ=Q/m=96 000/0,25=384 000 J/kg=384 kJ/kg.'},
{p:'Một mẫu băng 0,30 kg được đun từ −20°C đến đúng nhiệt độ nóng chảy bằng 12,6 kJ. Sau đó cần thêm 100,2 kJ để làm mẫu tan hoàn toàn. Cho c_đá=2100 J/(kg·K). Tính λ của băng theo kJ/kg.',ans:334,tol:0.5,a:'Phần tăng nhiệt đã khớp 0,30·2100·20=12,6 kJ. Phần nóng chảy Q=100,2 kJ nên λ=100,2/0,30=334 kJ/kg.'},
{p:'Một ấm chứa 0,50 kg nước ở 20°C. Công suất truyền hữu ích là 1,20 kW nhưng mất 15% công suất ra môi trường. Sau 140 s nước vừa đạt 100°C. Cho c=4200 J/(kg·K). Tính nhiệt dung riêng suy ra từ thí nghiệm theo J/(kg·K), làm tròn đơn vị.',ans:3570,tol:2,a:'Q_hữu ích=0,85·1200·140=142 800 J. c=Q/(mΔT)=142800/(0,50·80)=3570 J/(kg·K).'},
{p:'Một khối nước 0,80 kg ở 100°C hóa hơi một phần. Nhiệt lượng cung cấp là 600 kJ; trong thời gian đó khối nước vẫn ở 100°C. Cho L=2,26 MJ/kg. Tính khối lượng nước đã hóa hơi theo kg.',ans:0.2655,tol:0.001,a:'Ở 100°C, Q=Lm_hơi. m_hơi=600000/2,26·10^6≈0,2655 kg.'}
],
[
{p:'Khí lí tưởng đi từ A: p_A=1,20×10^5 Pa, V_A=1,50 L, T_A=300 K sang B: p_B=1,80×10^5 Pa, V_B=2,00 L. Sau đó sang C ở T_C=450 K và V_C=1,20 L. Tính p_C theo 10^5 Pa, giữ nguyên lượng khí.',ans:2.25,tol:0.01,a:'pV/T không đổi. p_C=p_A·V_A·T_C/(T_A·V_C)=1,20·1,50·450/(300·1,20)×10^5=2,25×10^5 Pa.'},
{p:'Một lượng khí có trạng thái A: p=1,00×10^5 Pa, V=2,0 L, T=300 K. A→B đẳng tích đến 450 K; B→C đẳng áp đến V_C=5,0 L; C→D đẳng nhiệt về V_D=3,0 L. Tính p_D theo 10^5 Pa.',ans:2.5,tol:0.01,a:'A→B: p_B=1,50×10^5 Pa. B→C đẳng áp nên p_C=1,50×10^5 Pa. C→D đẳng nhiệt: p_D=p_C·V_C/V_D=1,50·5/3=2,50×10^5 Pa.'},
{p:'Một bình kín cứng chứa khí ở 3,0×10^5 Pa và 300 K. Sau khi rò rỉ, số phân tử chỉ còn 60% nhưng nhiệt độ vẫn 300 K. Sau đó bình được nung đến 450 K. Tính áp suất cuối theo 10^5 Pa.',ans:2.7,tol:0.01,a:'Bình cứng nên p∝nT. Sau rò: p=0,60·3,0=1,80×10^5 Pa. Tăng T 1,5 lần ⇒ p=2,70×10^5 Pa.'},
{p:'Một piston giữ áp suất không đổi. Khi nhiệt độ tăng từ 27°C lên 177°C, thể tích tăng từ 1,80 L. Sau đó khí được nén đẳng nhiệt ở nhiệt độ mới đến 1,20 L. Nếu áp suất ban đầu là 1,00×10^5 Pa, tính áp suất sau nén theo 10^5 Pa.',ans:2.25,tol:0.01,a:'27°C=300 K; 177°C=450 K. V_2=1,80·450/300=2,70 L. Nén đẳng nhiệt: p_3=p_2V_2/V_3=1,00·2,70/1,20=2,25×10^5 Pa.'},
{p:'Một bình chứa 0,40 mol khí ở 320 K, thể tích 8,00 L. Dùng R=8,31 J/(mol·K). Tính áp suất theo 10^5 Pa, làm tròn 0,01.',ans:1.33,tol:0.01,a:'p=nRT/V=0,40·8,31·320/(8,00·10^-3)≈1,33×10^5 Pa.'},
{p:'Ở cùng một nhiệt độ, một phân tử khí có tốc độ hiệu dụng 500 m/s. Khi nhiệt độ tuyệt đối tăng lên 2,25 lần, tốc độ hiệu dụng tăng lên bao nhiêu m/s?',ans:750,tol:1,a:'v_rms∝√T nên v_2=500√2,25=750 m/s.'}
],
[
{p:'Một dây dài 0,40 m treo ngang trong từ trường đều B=0,25 T, dây vuông góc B. Khối lượng dây 30,0 g. Lấy g=9,8 m/s². Tính cường độ dòng điện để lực từ vừa cân bằng trọng lực, theo A.',ans:2.94,tol:0.01,a:'BIl=mg ⇒ I=mg/(Bl)=0,030·9,8/(0,25·0,40)=2,94 A.'},
{p:'Một proton bay vuông góc B=0,10 T với tốc độ 3,0×10^5 m/s và có bán kính quỹ đạo 0,0313 m. Lấy e=1,60×10^-19 C. Tính khối lượng suy ra theo 10^-27 kg.',ans:1.669,tol:0.01,a:'qvB=mv²/r ⇒ m=qBr/v=1,60×10^-19·0,10·0,0313/(3,0×10^5)=1,67×10^-27 kg.'},
{p:'Một hạt mang điện chuyển động tròn trong B=0,50 T. Chu kì quay đo được là 1,31×10^-7 s. Lấy e=1,60×10^-19 C. Nếu hạt là proton, tính khối lượng suy ra theo 10^-27 kg.',ans:1.67,tol:0.02,a:'T=2πm/(qB) ⇒ m=TqB/(2π)=1,31×10^-7·1,60×10^-19·0,50/(2π)≈1,67×10^-27 kg.'},
{p:'Hai từ trường vuông góc có độ lớn lần lượt 0,30 T và 0,40 T. Một điện tích chỉ chịu tổng từ trường này. Tính độ lớn cảm ứng từ tổng hợp theo T.',ans:0.50,tol:0.005,a:'Hai vector vuông góc: B=√(0,30²+0,40²)=0,50 T.'},
{p:'Một bộ chọn vận tốc dùng E=3,0×10^4 V/m và B=0,020 T. Hạt đi thẳng không lệch khi vE=qvB. Tính vận tốc theo 10^6 m/s.',ans:1.5,tol:0.01,a:'qE=qvB ⇒ v=E/B=3,0×10^4/0,020=1,50×10^6 m/s.'},
{p:'Một dây dài 0,50 m mang dòng 4,0 A trong B=0,30 T. Góc giữa dây và B là 30°. Dây chịu lực từ bao nhiêu N?',ans:0.30,tol:0.005,a:'F=BIl sin30°=0,30·4,0·0,50·0,50=0,30 N.'}
],
[
{p:'Mạch RLC nối tiếp có U=120 V, R=30 Ω, công suất tiêu thụ P=288 W. Tính cường độ dòng điện hiệu dụng theo A.',ans:3.10,tol:0.02,a:'P=I²R ⇒ I=√(288/30)=3,10 A.'},
{p:'Với mạch RLC nối tiếp, U=100 V, I=2,0 A, R=30 Ω. Biết XL>XC và L=0,10 H, C=50 μF. Tính tần số theo Hz.',ans:109.8,tol:0.2,a:'Z=U/I=50 Ω ⇒ |XL−XC|=√(Z²−R²)=40 Ω. Giải 2πfL−1/(2πfC)=40 cho f≈109,8 Hz.'},
{p:'Mạch có L=0,20 H và C=50 μF. Tính tần số cộng hưởng theo Hz.',ans:50.33,tol:0.05,a:'f0=1/(2π√LC)=1/(2π√(0,20·50·10^-6))≈50,33 Hz.'},
{p:'Một nguồn xoay chiều có U hiệu dụng 100 V, mạch thuần trở R=25 Ω. Tính công suất trung bình theo W.',ans:400,tol:1,a:'I=U/R=4 A; P=UI=400 W hoặc P=U²/R.'},
{p:'Tại một tần số, mạch RLC có Z=50 Ω và R=30 Ω. Tính |XL−XC| theo Ω.',ans:40,tol:0.2,a:'Z²=R²+(XL−XC)² ⇒ |XL−XC|=√(50²−30²)=40 Ω.'},
{p:'Mạch RLC có L=0,20 H, C=50 μF. Muốn chuyển từ trạng thái XL>XC về cộng hưởng, tần số hiện tại là 80 Hz. Tần số phải thay đổi còn bao nhiêu Hz?',ans:50.33,tol:0.1,a:'Cộng hưởng tại f0=1/(2π√LC)=50,33 Hz. Vì đang XL>XC nên cần giảm tần số xuống f0.'}
],
[
{p:'Thanh dẫn dài 0,40 m chuyển động vuông góc B=0,50 T với v=3,0 m/s; mạch có R=1,50 Ω. Tính lực cơ cần duy trì vận tốc không đổi theo N.',ans:0.08,tol:0.002,a:'e=Blv=0,60 V; I=e/R=0,40 A; lực từ cản F=BIl=0,50·0,40·0,40=0,080 N.'},
{p:'Một thanh quay quanh một đầu trong B đều, chiều dài 0,30 m, B=0,40 T, tốc độ góc 20 rad/s. Tính suất điện động giữa hai đầu theo V.',ans:0.36,tol:0.005,a:'e=(1/2)BωL²=0,5·0,40·20·0,30²=0,36 V.'},
{p:'Cuộn dây 200 vòng có từ thông qua mỗi vòng giảm đều 0,020 Wb trong 0,100 s. Tính độ lớn suất điện động cảm ứng theo V.',ans:40,tol:0.2,a:'|e|=N|ΔΦ|/Δt=200·0,020/0,100=40 V.'},
{p:'Một mạch kín có điện trở 0,50 Ω nhận suất điện động cảm ứng 2,0 V trong 0,25 s. Tính nhiệt lượng tỏa ra trong khoảng thời gian đó theo J.',ans:8,tol:0.05,a:'I=e/R=4 A; Q=I²Rt=16·0,50·0,25=8 J.'},
{p:'Máy biến áp lí tưởng có N1=1000 vòng, N2=100 vòng, U1=220 V. Tính U2 theo V. Nếu tải tiêu thụ 44 W thì dòng thứ cấp là bao nhiêu A?',ans:2.0,tol:0.02,a:'U2/U1=N2/N1 ⇒ U2=22 V. I2=P/U2=44/22=2,0 A.'},
{p:'Một máy phát có suất điện động hiệu dụng 100 V. Bỏ qua tổn hao. Tính suất điện động cực đại theo V, làm tròn 0,1 V.',ans:141.4,tol:0.1,a:'E0=√2·E=141,4 V.'}
],
[
{p:'Radar phát xung có tần số 10 GHz. Xung phản xạ trở về sau 8,0 μs. Lấy c=3,0×10^8 m/s. Tính khoảng cách đến mục tiêu theo m.',ans:1200,tol:2,a:'S=ct/2=3·10^8·8·10^-6/2=1200 m.'},
{p:'Sóng điện từ có tần số 6,0×10^14 Hz truyền trong môi trường chiết suất n=1,50. Lấy c=3,0×10^8 m/s. Tính bước sóng theo nm.',ans:333.3,tol:1,a:'v=c/n=2,0×10^8 m/s. λ=v/f=3,33×10^-7 m=333 nm.'},
{p:'Một radar đo khoảng cách bằng xung điện từ. Nếu thời gian khứ hồi giảm từ 6,0 μs xuống 4,0 μs thì khoảng cách mới là bao nhiêu m?',ans:600,tol:2,a:'S=ct/2=3·10^8·4·10^-6/2=600 m.'},
{p:'Một anten có chiều dài bằng một phần tư bước sóng và dài 2,50 m. Tính tần số bức xạ phù hợp theo MHz.',ans:30,tol:0.2,a:'λ=4L=10 m; f=c/λ=3·10^8/10=30 MHz.'},
{p:'Một thiết bị phát 20 chu kì sóng điện từ trong 2,0 μs. Tính bước sóng trong chân không theo m.',ans:30,tol:0.2,a:'f=20/(2·10^-6)=10 MHz; λ=c/f=3·10^8/(10·10^6)=30 m.'},
{p:'Một tín hiệu vô tuyến có bước sóng 12 m. Tính tần số theo MHz trong chân không.',ans:25,tol:0.2,a:'f=c/λ=3·10^8/12=25 MHz.'}
],
[
{p:'Một nguồn phóng xạ có chu kì bán rã 6,0 giờ. Sau 15 giờ, phần trăm số hạt chưa phân rã còn lại là bao nhiêu? Làm tròn 0,1%.',ans:17.7,tol:0.2,a:'N/N0=2^{-15/6}=2^{-2,5}=0,1768 ⇒ 17,7%.'},
{p:'Hoạt độ ban đầu là 8,0×10^6 Bq, chu kì bán rã 10 ngày. Sau 30 ngày hoạt độ còn bao nhiêu Bq?',ans:1000000,tol:5000,a:'30 ngày=3T1/2 ⇒ A=A0/8=1,0×10^6 Bq.'},
{p:'Một hạt nhân có độ hụt khối 0,200 u và số khối A=20. Lấy 1u c²=931,5 MeV. Tính năng lượng liên kết riêng theo MeV/nucleon.',ans:9.315,tol:0.02,a:'E_lk=0,200·931,5=186,3 MeV. Liên kết riêng=186,3/20=9,315 MeV/nucleon.'},
{p:'Một phản ứng hạt nhân có tổng khối lượng trước phản ứng lớn hơn sau phản ứng 0,0050 u. Tính năng lượng tỏa ra theo MeV.',ans:4.6575,tol:0.01,a:'Q=Δm·931,5=0,0050·931,5=4,6575 MeV.'},
{p:'Trong phản ứng tổng hợp 4H→He, phần khối lượng giảm là 0,026 u. Lấy 1u c²=931,5 MeV. Tính năng lượng tỏa ra cho một phản ứng theo MeV.',ans:24.219,tol:0.02,a:'Q=0,026·931,5=24,219 MeV.'},
{p:'Một nguồn phóng xạ có hoạt độ 1,0×10^12 Bq, mỗi phân rã giải phóng 5,0 MeV; thiết bị biến 20% năng lượng đó thành điện năng. Tính công suất điện trung bình theo W.',ans:0.1602,tol:0.002,a:'P=A·E·η=10^12·(5·10^6·1,602·10^-19)·0,20≈0,160 W.'}
],
[
{p:'Kim loại có giới hạn quang điện λ0=600 nm. Chiếu ánh sáng λ=400 nm. Lấy hc=1240 eV·nm. Tính động năng cực đại của electron theo eV.',ans:1.033,tol:0.01,a:'K=hc/λ−hc/λ0=1240/400−1240/600=1,033 eV.'},
{p:'Một tế bào quang điện cho U_h=2,00 V khi chiếu λ=300 nm. Lấy hc=1240 eV·nm. Tính công thoát theo eV.',ans:2.133,tol:0.01,a:'A=hc/λ−eU_h=1240/300−2,00=2,133 eV.'},
{p:'Một laser công suất 3,20 mW phát ánh sáng đơn sắc λ=640 nm. Lấy h=6,626×10^-34 J·s, c=3,00×10^8 m/s. Tính số photon phát ra mỗi giây theo 10^16 photon/s.',ans:1.03,tol:0.02,a:'N=P/(hc/λ)=Pλ/(hc)≈1,03×10^16 photon/s.'},
{p:'Một chùm photon đập vào catốt với tốc độ 2,0×10^16 photon/s, tạo dòng quang điện bão hòa 0,48 mA. Lấy e=1,60×10^-19 C. Tính hiệu suất lượng tử theo %.',ans:15,tol:0.5,a:'Số electron/s=I/e=0,48·10^-3/(1,60·10^-19)=3,0×10^15. Hiệu suất=3,0/20=15%.'},
{p:'Kim loại có công thoát 2,20 eV. Lấy h=4,14×10^-15 eV·s. Tính tần số giới hạn theo 10^14 Hz.',ans:5.31,tol:0.03,a:'f0=A/h=2,20/(4,14×10^-15)=5,31×10^14 Hz.'},
{p:'Khi chiếu λ=500 nm vào một kim loại, điện thế hãm là 0,80 V. Sau đó đổi sang λ=400 nm. Lấy hc=1240 eV·nm. Tính điện thế hãm mới theo V.',ans:1.42,tol:0.02,a:'A=1240/500−0,80=1,68 eV. Với 400 nm: K=3,10−1,68=1,42 eV ⇒ U_h=1,42 V.'}
],
[
{p:'Electron trong nguyên tử H chuyển từ n=4 xuống n=2. Dùng En=−13,6/n² eV và hc=1240 eV·nm. Tính bước sóng photon theo nm.',ans:486.3,tol:1,a:'ΔE=13,6(1/4−1/16)=2,55 eV. λ=1240/2,55≈486,3 nm.'},
{p:'Một electron H đang ở mức n=3. Tối thiểu cần cung cấp bao nhiêu eV để ion hóa hoàn toàn nguyên tử từ trạng thái đó?',ans:1.511,tol:0.01,a:'E3=−13,6/9=−1,511 eV. Đưa lên E∞=0 cần 1,511 eV.'},
{p:'Electron H chuyển từ n=5 xuống n=3. Tính bước sóng photon theo nm, dùng hc=1240 eV·nm.',ans:1282,tol:3,a:'ΔE=13,6(1/9−1/25)=0,9671 eV. λ=1240/0,9671≈1282 nm.'},
{p:'Ống tia X hoạt động ở hiệu điện thế tăng tốc 40 kV. Tính bước sóng ngắn nhất theo nm, dùng hc=1240 eV·nm.',ans:0.0310,tol:0.001,a:'λmin=hc/eU=1240/40000=0,0310 nm.'},
{p:'Một ống tia X đang hoạt động ở 40 kV có λmin=0,050 nm. Nếu muốn λmin giảm còn 0,040 nm thì hiệu điện thế tăng tốc phải tăng thành bao nhiêu kV?',ans:50,tol:0.5,a:'λmin∝1/U. U2=U1·λ1/λ2=40·0,050/0,040=50 kV nếu U1 tương ứng 0,050 nm là 40 kV.'},
{p:'Một nguyên tử H được kích thích lên n=6 và có thể phát xạ qua mọi chuyển mức xuống các mức thấp hơn. Có bao nhiêu vạch phổ phát xạ khác nhau?',ans:15,tol:0.1,a:'Số chuyển mức khác nhau giữa 6 mức là C(6,2)=15.'}
]
];
const shortExtraByChapter = [
[
{p:'Một hệ gồm 0,30 kg nước ở 80°C và 0,20 kg nước đá ở −20°C trong bình cách nhiệt. Sau cân bằng còn đúng 0,05 kg đá chưa tan. Cho c_n=4200, c_đ=2100, λ=334000. Tính nhiệt độ cân bằng theo °C.',ans:12.19,tol:0.02,a:'Đá cần 0,20·2100·20+0,20·334000=75200 J để lên 0°C và tan hết. Nước nóng tỏa 0,30·4200·80=100800 J. Còn 25600 J làm nóng 0,50 kg nước: ΔT=25600/(0,50·4200)=12,19°C. Vậy T≈12,19°C.'},
{p:'Một thí nghiệm đun 0,40 kg nước từ 25°C đến 100°C dùng công suất điện 900 W trong 180 s. Biết nhiệt dung bình là 250 J/K và hiệu suất truyền nhiệt 75%. Tính c của nước theo J/(kg·K).',ans:3425,tol:5,a:'Điện năng hữu ích=0,75·900·180=121500 J. Nhiệt thu của nước và bình: 0,40·c·75+250·75=121500. Suy ra c=3425 J/(kg·K). Không được bỏ qua nhiệt dung bình.'},
{p:'Một mẫu chất 0,20 kg nhận 150 kJ: 30 kJ làm tăng nhiệt độ, phần còn lại dùng hóa hơi. Nếu tại nhiệt độ sôi L=600 kJ/kg, tính phần khối lượng đã hóa hơi theo kg.',ans:0.2,tol:0.005,a:'Q_hóa hơi=150−30=120 kJ. m=120/600=0,20 kg.'},
{p:'Một khối băng 0,50 kg ở −10°C được cấp 210 kJ. Cho c_đ=2100 J/(kg·K), λ=334 kJ/kg. Hỏi cuối cùng còn bao nhiêu kg băng?',ans:0,tol:0.001,a:'Đưa băng lên 0°C cần 10,5 kJ; còn 199,5 kJ làm tan m=199,5/334≈0,597 kg >0,50 kg nên băng tan hết. Nhiệt còn lại làm nước tăng nhiệt; khối lượng băng cuối bằng 0.'}
],
[
{p:'Khí lí tưởng có p1=1,2×10^5 Pa, V1=2 L, T1=300 K. Khí nở đẳng áp đến 3 L rồi được nung đẳng tích đến 600 K. Tính áp suất cuối theo 10^5 Pa.',ans:1.6,tol:0.01,a:'Nở đẳng áp: T2=300·3/2=450 K. Đẳng tích: p3=1,2·600/450=1,60×10^5 Pa.'},
{p:'Một lượng khí bị nén đẳng nhiệt từ 5 L xuống 2 L. Áp suất tăng thêm 1,5×10^5 Pa. Tính áp suất ban đầu theo 10^5 Pa.',ans:1.0,tol:0.01,a:'p1V1=p2V2 và p2=p1+1,5×10^5. Suy ra 5p1=2(p1+1,5), nên 3p1=3 ⇒ p1=1,0×10^5 Pa.'},
{p:'Một bình cứng chứa khí ở 2,0×10^5 Pa, 300 K. Rút 25% số mol rồi nung phần khí còn lại đến 450 K. Tính áp suất cuối theo 10^5 Pa.',ans:2.25,tol:0.01,a:'Bình cứng: p∝nT. Sau rút: 0,75·2,0=1,5. Tăng nhiệt 450/300=1,5 ⇒ p=2,25×10^5 Pa.'},
{p:'Một khí có V=4,0 L ở 300 K. Giữ áp suất không đổi, sau đó nhiệt độ tăng thêm 150 K. Khí thực hiện công 6,0 kJ. Tính áp suất theo 10^5 Pa.',ans:30,tol:0.1,a:'ΔV=4·150/300=2 L=0,002 m³. W=pΔV=6000 J ⇒ p=3,0×10^6 Pa=30×10^5 Pa.'}
],
[
{p:'Một electron bay vuông góc B=0,002 T với bán kính 0,010 m. Biết e=1,60×10^-19 C, m=9,11×10^-31 kg. Tính tốc độ theo 10^6 m/s.',ans:3.51,tol:0.01,a:'qvB=mv²/r ⇒ v=qBr/m≈3,51×10^6 m/s.'},
{p:'Một dây dài 0,60 m mang dòng 5 A trong B=0,40 T, góc giữa dây và B là θ. Lực từ đo được 0,30 N. Tính sinθ.',ans:0.5,tol:0.01,a:'F=BIl sinθ ⇒ sinθ=0,30/(0,40·5·0,60)=0,50.'},
{p:'Một proton được gia tốc qua hiệu điện thế 2,0 kV rồi đi vuông góc vào B=0,10 T. Bỏ qua tương đối tính, lấy m=1,67×10^-27 kg, e=1,60×10^-19 C. Tính bán kính quỹ đạo theo cm.',ans:6.46,tol:0.05,a:'eU=mv²/2 ⇒ v=√(2eU/m). Sau đó r=√(2mU/e)/B≈0,0646 m=6,46 cm.'},
{p:'Một dây dẫn chịu lực từ 0,90 N khi I=6 A, B=0,30 T, L=0,50 m. Tính góc giữa dây và B.',ans:90,tol:0.5,a:'sinθ=F/(BIL)=0,90/(0,30·6·0,50)=1. Vì vậy θ=90°.'}
],
[
{p:'Mạch RLC có R=40 Ω, U=200 V, cosφ=0,60. Tính công suất trung bình theo W và I hiệu dụng theo A.',ans:600,tol:1,a:'P=UIcosφ=200·I·0,60 và P=I²R. Suy ra I=Ucosφ/R=3 A, P=600 W.'},
{p:'Mạch có R=24 Ω, U=120 V và P=432 W. Tính |XL−XC| theo Ω.',ans:14.97,tol:0.05,a:'I=√(P/R)=√18≈4,243 A; Z=U/I≈28,284 Ω. |XL−XC|=√(Z²−R²)≈14,97 Ω.'},
{p:'Mạch RLC có L=0,10 H, C=100 μF. Nếu tần số tăng từ 40 Hz lên 80 Hz, hãy tính XL và XC tại 80 Hz rồi kết luận tính cảm/ dung.',ans:50.27,tol:0.1,a:'Tại 80 Hz: XL=2πfL≈50,27 Ω; XC=1/(2πfC)≈19,89 Ω. Vì XL>XC nên mạch có tính cảm.'},
{p:'Một tải tiêu thụ công suất 1,20 kW ở U=240 V, cosφ=0,80. Tính dòng điện hiệu dụng theo A.',ans:6.25,tol:0.02,a:'P=UIcosφ ⇒ I=1200/(240·0,80)=6,25 A.'}
],
[
{p:'Một thanh dài 0,50 m trượt với v=4 m/s trong B=0,30 T, R=2 Ω. Trong 5 s, điện năng tỏa trên R bằng bao nhiêu J?',ans:0.90,tol:0.01,a:'e=Blv=0,60 V; I=0,30 A; P=I²R=0,18 W; E=Pt=0,90 J.'},
{p:'Một cuộn 500 vòng có từ thông mỗi vòng giảm từ 4,0 mWb xuống 1,0 mWb trong 0,050 s. Tính suất điện động cảm ứng theo V.',ans:30,tol:0.1,a:'e=N|ΔΦ|/Δt=500·0,003/0,050=30 V.'},
{p:'Máy biến áp lí tưởng giảm áp từ 220 V xuống 22 V. Nếu dòng sơ cấp 0,50 A thì dòng thứ cấp là bao nhiêu A?',ans:5,tol:0.05,a:'U1I1=U2I2 ⇒ I2=220·0,50/22=5 A.'},
{p:'Một khung dây có 200 vòng, diện tích 0,010 m² quay trong B=0,50 T với ω=100 rad/s. Tính suất điện động cực đại theo V.',ans:100,tol:1,a:'E0=NBSω=200·0,50·0,010·100=100 V.'}
],
[
{p:'Một radar phát sóng 5,0 GHz. Tín hiệu phản xạ sau 12 μs. Tính khoảng cách mục tiêu theo km.',ans:1.8,tol:0.01,a:'d=ct/2=3×10^8·12×10^-6/2=1800 m=1,80 km.'},
{p:'Một sóng điện từ trong môi trường có n=1,25 và f=2,0×10^14 Hz. Tính bước sóng theo μm.',ans:1.2,tol:0.01,a:'v=c/n=2,4×10^8 m/s; λ=v/f=1,2×10^-6 m=1,2 μm.'},
{p:'Một anten phát ở 75 MHz. Tính một phần tư bước sóng theo m.',ans:1,tol:0.01,a:'λ=c/f=4 m; λ/4=1 m.'},
{p:'Một tín hiệu truyền qua cáp với vận tốc 2,0×10^8 m/s và tần số 100 MHz. Tính bước sóng theo m.',ans:2,tol:0.01,a:'λ=v/f=2×10^8/10^8=2 m.'}
],
[
{p:'Nguồn phóng xạ có T1/2=8 ngày. Sau 24 ngày, khối lượng còn 12,5 g. Tính khối lượng ban đầu theo g.',ans:100,tol:0.5,a:'24 ngày=3 chu kỳ bán rã ⇒ còn 1/8. m0=12,5·8=100 g.'},
{p:'Một phản ứng có Q=200 MeV cho mỗi sự kiện. Nếu xảy ra 3,0×10^12 sự kiện/s, tính công suất theo W, dùng 1 eV=1,602×10^-19 J.',ans:96.12,tol:0.2,a:'E/s=3×10^12·200×10^6·1,602×10^-19≈96,12 W.'},
{p:'Một mẫu có hoạt độ giảm từ 8,0×10^7 Bq xuống 1,0×10^7 Bq sau 18 giờ. Tính chu kỳ bán rã theo giờ.',ans:6,tol:0.1,a:'Tỉ số 1/8=2^-3 nên 18=3T1/2 ⇒ T1/2=6 h.'},
{p:'Hai hạt nhân có năng lượng liên kết lần lượt 480 MeV và 520 MeV, số nucleon tương ứng 56 và 62. Hạt nào bền hơn xét theo năng lượng liên kết riêng? Tính chênh lệch theo MeV/nucleon.',ans:0.18,tol:0.01,a:'BE1≈8,57 MeV/nucleon; BE2≈8,39 MeV/nucleon. Hạt 1 bền hơn; chênh lệch≈0,18 MeV/nucleon.'}
],
[
{p:'Kim loại có công thoát 2,50 eV. Chiếu photon 350 nm. Lấy hc=1240 eV·nm. Tính U_h theo V.',ans:1.043,tol:0.01,a:'Eγ=1240/350=3,543 eV; Kmax=1,043 eV ⇒ U_h=1,043 V.'},
{p:'Một nguồn laser 5 mW phát λ=500 nm. Tính số photon phát ra mỗi giây theo 10^16 photon/s.',ans:1.26,tol:0.02,a:'N=Pλ/(hc)=5×10^-3·500×10^-9/(6,626×10^-34·3×10^8)≈1,26×10^16.'},
{p:'Tế bào quang điện có U_h=1,20 V khi chiếu 400 nm. Tính công thoát theo eV.',ans:1.90,tol:0.02,a:'A=1240/400−1,20=3,10−1,20=1,90 eV.'},
{p:'Hai photon có bước sóng 300 nm và 600 nm. Photon thứ nhất có năng lượng gấp bao nhiêu lần photon thứ hai?',ans:2,tol:0.01,a:'E∝1/λ ⇒ E300/E600=600/300=2.'}
],
[
{p:'Electron H chuyển từ n=5 xuống n=2. Tính năng lượng photon theo eV.',ans:2.856,tol:0.01,a:'ΔE=13,6(1/4−1/25)=2,856 eV.'},
{p:'Một ống tia X hoạt động 60 kV. Tính λmin theo pm.',ans:20.67,tol:0.1,a:'λmin=1240/60000 nm=0,02067 nm=20,67 pm.'},
{p:'Electron H đang ở n=4. Có bao nhiêu vạch phát xạ tối đa khi electron có thể chuyển qua mọi mức thấp hơn?',ans:6,tol:0.1,a:'Số chuyển mức giữa 4 mức là C(4,2)=6.'},
{p:'Tia X có λ=0,05 nm. Tính năng lượng photon theo keV.',ans:24.8,tol:0.1,a:'E=hc/λ=1240/0,05=24800 eV=24,8 keV.'}
]
];

// Gộp 6 câu nền + 4 câu tăng cường thành 10 câu/chương.
const shortHardByChapter10 = shortHardByChapter.map((base,i)=>base.concat(shortExtraByChapter[i]||[]));
const shortHard = shortHardByChapter10.flat();
