/* Mô tả 10 đề trong Kho đề */
const examMeta=[
  'Nhiệt học, khí lí tưởng, lực từ và hạt nhân; nhiều câu yêu cầu kiểm tra điều kiện áp dụng.',
  'Khí lí tưởng, dòng xoay chiều, phóng xạ và bài đồ thị; chú trọng suy luận từ trạng thái.',
  'Nhiệt học, chuyển thể, từ trường và năng lượng liên kết; nhiều câu định lượng ngược.',
  'Nhiệt học–khí, quá trình p–V và điện từ; dùng dữ kiện liên hoàn.',
  'Bài tổng hợp nhiều chương, ưu tiên tình huống thực nghiệm và đại lượng suy ngược.',
  'Bài phối hợp khí–từ–hạt nhân, có dữ liệu trung gian và kiểm tra tính nhất quán.',
  'Tập trung các tình huống thiết bị thực tế, từ trường, phóng xạ và năng lượng.',
  'Nội năng, nhiệt độ, khí lí tưởng và các ứng dụng hiện đại của vật lí.',
  'Các bài thực nghiệm, đồ thị và tính toán liên hoàn; ưu tiên nhận diện mô hình.',
  'Máy phát điện, RLC, nhiệt học, hạt nhân và tia X; nhiều câu dùng dữ kiện chung.'
];
