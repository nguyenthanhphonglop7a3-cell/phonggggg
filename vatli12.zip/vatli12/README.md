# Vật lí 12 — web ôn tập

Mở `index.html` bằng trình duyệt (hoặc dùng Live Server trong VS Code).

## Cấu trúc
```
index.html            Khung trang (HTML)
css/style.css         Giao diện
js/
  data/               DỮ LIỆU — chỗ bạn sửa/thêm câu hỏi
    chapters.js         9 chương và danh sách bài
    theory.js           Lý thuyết từng bài
    truefalse.js        Đúng/Sai (mỗi tình huống có "ch" = số chương)
    short.js            Trả lời ngắn (10 câu/chương)
    essays.js           Tự luận + lời giải
    exam-meta.js        Mô tả 10 đề trong Kho đề
  core.js             Hàm chung, trang chủ, lý thuyết, công thức
  quiz-generators.js  Trắc nghiệm theo chương (bộ sinh số liệu tự động)
  mcq-templates.js    17 mẫu trắc nghiệm cũ (chỉ dùng cho Kho đề)
  practice.js         Tab Trắc nghiệm / Đúng-Sai / Trả lời ngắn / Tự luận
  exams.js            Kho đề
  ui.js               Âm thanh, sáng/tối, khởi tạo
```
Thứ tự nạp script trong `index.html` quan trọng: file dữ liệu trước, `ui.js` cuối cùng.

## Thêm một tình huống Đúng/Sai
Mở `js/data/truefalse.js`, thêm vào mảng:
```js
{ "ch": 3, "title": "...", "context": "...",
  "a": [ ["Mệnh đề a", 1, "Giải thích"], ["Mệnh đề b", 0, "Giải thích"], ... ] }
```
`1` = Đúng, `0` = Sai; `ch` là số chương (1–9).
